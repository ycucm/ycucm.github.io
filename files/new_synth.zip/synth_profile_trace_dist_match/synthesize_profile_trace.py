"""
Batch synthesis for new users (profile + trace).

Design goals:
1) Parent pool follows profile-embed filtering logic:
   - split == 0
   - non-empty inter_user_profile_with_sid
   - non-empty hist_video_pid
2) Profile synthesis uses ``synth_user_xr/synth_user/synth_user.py``:
   interleave_history → merge_persona → assemble_rich_profile (natural-language
   ``inter_user_profile_with_sid``, aligned with synth_user_xr README).
3) Trace synthesis (separate from profile hist):
   - sample ~sample_ratio from each parent's trace
   - interleave as temporary seq seed
   - OpenOneRec (vLLM/transformers) autoregressive generation for target_len items
   - discard seed, keep generated trace only
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import random
import re
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
try:
    import torch
except Exception:
    torch = None
try:
    from transformers import AutoModelForCausalLM, AutoTokenizer
except Exception:
    AutoModelForCausalLM = None
    AutoTokenizer = None
try:
    from vllm import LLM, SamplingParams
except Exception:
    LLM = None
    SamplingParams = None


DATA_PATH = Path("/home/lzq/usersim/OpenOneRec/data_v1.0/onerec_bench_release.parquet")
PID2SID_PATH = Path("/home/lzq/usersim/OpenOneRec/data_v1.0/video_ad_pid2sid.parquet")
PRD_SID_PATH = Path("/home/lzq/usersim/OpenOneRec/data_v1.0/product_pid2sid.parquet")
SID2PID_PATH = Path("/home/lzq/usersim/OpenOneRec/data_v1.0/benchmark_data/sid2pid.json")
CHAT_TEMPLATE_PATH = Path("/home/lzq/usersim/OpenOneRec/benchmarks/benchmark/tasks/v1_0/qwen3_soft_switch.jinja2")
DEFAULT_MODEL_PATH = "/home/lzq/usersim/OpenOneRec/models/OneRec-1.7B"

OUT_DIR = Path("/home/lzq/usersim/synth_profile_trace_dist_match/output")

SYSTEM_MSG = "你是一个内容推荐专家，擅长分析用户的互动模式，预测用户接下来会观看的短视频。"
PROFILE_SYNTH_SYSTEM_MSG = "你是一个高质量用户画像合成专家。"
PROFILE_SYNTH_PROMPT_TEMPLATE = """请基于用户A与用户B，合成一个“新用户画像”。
最终目标是输出一段与历史数据风格一致的自然语言 user profile 文本（类似 inter_user_profile_with_sid）。

【核心要求】
1) 你必须先在内部完成结构化融合（可先形成 JSON 草稿），再将其转写成最终自然语言画像文本。
2) 最终只输出“自然语言画像文本”，不要输出JSON、不要输出解释、不要输出推理过程。
3) 不要包含“用户评论”相关内容（例如“最近评论的视频”及其评论文本）。
4) 除评论外，其它可用信息都应尽量保留并融合。
5) 融合时不要机械地逐字段按 alpha 线性混合；你可以在一定程度上自主决策，但必须符合 merge A/B 的逻辑：
   - 优先保留 A/B 的共同点（overlap）作为核心画像；
   - 对互补信息做有控制的合并，避免冲突与噪声堆叠；
   - 对冲突信息做合理取舍，并保持整体人设一致。
6) 结果要像真实用户画像文本，语言自然、连贯、信息密度高但不冗余。

【融合指导（软约束）】
- 人口属性（性别/年龄）：以信息更明确、更一致的一侧为主；冲突时参考 alpha，但可结合上下文做合理裁决。
- 兴趣/行为列表（搜索、直播、点击广告、转化广告、消费类目等）：优先保留 overlap，再补充少量互补项；去重、去矛盾，控制长度。
- 占比类信息（如关注博主类型）：可做近似加权与归一化，但不要求严格公式化；重点是可读、可信。
- 文本摘要类（广告兴趣、挂车消费、最近观看广告等）：整合成一致叙述，避免互相打架。
- 禁止输出评论相关字段或评论原文。

【风格要求】
- 输出是一段完整中文画像文本，风格贴近历史 user profile。
- 覆盖维度尽量完整：人口属性、内容偏好、搜索与直播、广告与商业化行为、消费倾向等。
- 不使用“A用户/B用户/融合后”等元叙述，不暴露生成过程。

【长度建议】
- 与历史 profile 文本量级接近（中长文本），避免过短摘要。

【参数】
alpha = {alpha}

【用户A】
{profile_a}

【用户B】
{profile_b}

请直接输出最终的自然语言用户画像文本（仅文本本体）："""
INJECTION_PATTERNS = [
    r"无需思考",
    r"请直接输出最终的自然语言用户画像文本",
    r"仅文本本体",
    r"\bassistant\b",
    r"\buser\b",
    r"\boutput\b",
    r"\bbegin\b",
    r"\bno_think\b",
    r"不要生成任何描述",
    r"只需要文本",
    r"不要输出任何说明",
]
SID_RE = re.compile(r"<s_a_(\d+)><s_b_(\d+)><s_c_(\d+)>")
SID_FMT = "<|sid_begin|><s_a_{c0}><s_b_{c1}><s_c_{c2}><|sid_end|>"
CODE_MULT_1 = 8192 * 8192
CODE_MULT_2 = 8192

# Matches synth_user_xr/synth_user/synth_user.py
BEHAVIOR_COLS_XR = [
    "hist_video_like",
    "hist_video_follow",
    "hist_video_forward",
    "hist_video_longview",
    "hist_video_not_interested",
]


def _import_synth_user_xr():
    """Load synth_user_xr implementation without installing as a package."""
    xr_py = Path(__file__).resolve().parent.parent / "synth_user_xr" / "synth_user" / "synth_user.py"
    if not xr_py.is_file():
        raise FileNotFoundError(f"Expected synth_user_xr at {xr_py}")
    spec = importlib.util.spec_from_file_location("synth_user_xr_synth", xr_py)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def _load_pid2sid_str_for_profile() -> dict[int, str]:
    """Same token strings as synth_user_xr load_pid2sid (video + product tables)."""

    def _build(path: Path) -> dict[int, str]:
        df = pd.read_parquet(path)
        out: dict[int, str] = {}
        for row in df.itertuples(index=False):
            a, b, c = row.sid
            out[int(row.new_pid)] = (
                f"<|sid_begin|><s_a_{a}><s_b_{b}><s_c_{c}><|sid_end|>"
            )
        return out

    pid2sid = _build(PID2SID_PATH)
    if PRD_SID_PATH.is_file():
        pid2sid.update(_build(PRD_SID_PATH))
    return pid2sid


def _alpha_sample(list_a: list, list_b: list, alpha: float, rng: random.Random, cap: int | None = None) -> list:
    n = cap or max(len(list_a) + len(list_b), 1)
    k_a = round(n * alpha)
    k_b = round(n * (1 - alpha))
    sampled = (
        rng.sample(list_a, min(k_a, len(list_a)))
        + rng.sample(list_b, min(k_b, len(list_b)))
    )
    rng.shuffle(sampled)
    return sampled


def _merge_follow_list(list_a: list, list_b: list, alpha: float) -> list:
    combined = defaultdict(float)
    for item in list_a:
        cat = item.get("博主类型", "")
        pct = float(item.get("占比", 0))
        if cat:
            combined[cat] += pct * alpha
    for item in list_b:
        cat = item.get("博主类型", "")
        pct = float(item.get("占比", 0))
        if cat:
            combined[cat] += pct * (1 - alpha)
    total = sum(combined.values())
    if total > 0:
        combined = {k: v * 100.0 / total for k, v in combined.items()}
    return sorted(
        [{"博主类型": k, "占比": round(v, 2)} for k, v in combined.items()],
        key=lambda x: -x["占比"],
    )


def _merge_video_categories(cats_a: dict, cats_b: dict, alpha: float) -> dict:
    merged = {}
    for key in set(list(cats_a.keys()) + list(cats_b.keys())):
        va = cats_a.get(key, [])
        vb = cats_b.get(key, [])
        combined = []
        n_a = max(round(2 * alpha), 1 if va else 0)
        n_b = max(round(2 * (1 - alpha)), 1 if vb else 0)
        combined.extend(va[:n_a])
        combined.extend([x for x in vb[:n_b] if x not in combined])
        merged[key] = combined[:3]
    return merged


def merge_persona_local(user_a: dict, user_b: dict, alpha: float, seed: int) -> dict:
    rng = random.Random(seed + 99)
    da = user_a.get("_profile_json", {})
    db = user_b.get("_profile_json", {})
    p = {}
    p["性别"] = da.get("性别") or db.get("性别") or ""
    age_a = da.get("年龄") or ""
    age_b = db.get("年龄") or ""
    p["年龄"] = age_a if (age_a and alpha >= 0.5) else (age_b or age_a)
    p["关注博主类型"] = _merge_follow_list(
        da.get("关注博主类型", []),
        db.get("关注博主类型", []),
        alpha,
    )
    p["视频生产类目"] = _alpha_sample(
        da.get("视频生产类目", []),
        db.get("视频生产类目", []),
        alpha,
        rng,
    )[:5]
    p["视频消费类目"] = _merge_video_categories(
        da.get("视频消费类目", {}),
        db.get("视频消费类目", {}),
        alpha,
    )
    p["最近搜索内容"] = _alpha_sample(
        da.get("最近搜索内容", []),
        db.get("最近搜索内容", []),
        alpha,
        rng,
        cap=30,
    )[:30]
    p["最近观看的直播"] = _alpha_sample(
        da.get("最近观看的直播", []),
        db.get("最近观看的直播", []),
        alpha,
        rng,
    )
    p["最近评论的视频"] = _alpha_sample(
        da.get("最近评论的视频", []),
        db.get("最近评论的视频", []),
        alpha,
        rng,
        cap=20,
    )[:17]
    p["曝光并且转化的广告"] = _alpha_sample(
        da.get("曝光并且转化的广告", []),
        db.get("曝光并且转化的广告", []),
        alpha,
        rng,
    )[:4]
    p["曝光并且点击的广告"] = _alpha_sample(
        da.get("曝光并且点击的广告", []),
        db.get("曝光并且点击的广告", []),
        alpha,
        rng,
    )[:3]
    ad_a = da.get("最近在平台上对以下视频中的广告意图表示感兴趣", "")
    ad_b = db.get("最近在平台上对以下视频中的广告意图表示感兴趣", "")
    p["广告兴趣"] = ad_a if rng.random() < alpha else (ad_b or ad_a)
    pu_a = da.get("最近对平台上这些挂车商品感兴趣并产生了消费行为", "")
    pu_b = db.get("最近对平台上这些挂车商品感兴趣并产生了消费行为", "")
    p["挂车消费"] = pu_a if (pu_a and rng.random() < alpha) else (pu_b or pu_a)
    biz_a = da.get("最近商业化其他行为", {})
    biz_b = db.get("最近商业化其他行为", {})
    p["最近商业化其他行为"] = {**biz_b, **biz_a} if alpha >= 0.5 else {**biz_a, **biz_b}
    wa_a = da.get("最近观看的广告", "")
    wa_b = db.get("最近观看的广告", "")
    p["最近观看的广告"] = wa_a if (wa_a and rng.random() < alpha) else (wa_b or wa_a)
    return p


def _build_profile_field_pools(df: pd.DataFrame) -> dict:
    """Collect lightweight global pools from valid profile JSON rows."""
    pools = {
        "性别": [],
        "年龄": [],
        "视频生产类目": [],
        "最近搜索内容": [],
        "最近观看的直播": [],
    }
    for _, row in df.iterrows():
        txt = row.get("inter_user_profile_with_sid")
        if not isinstance(txt, str) or not txt.strip():
            continue
        try:
            j = json.loads(txt)
        except Exception:
            continue
        if not isinstance(j, dict):
            continue
        if j.get("性别"):
            pools["性别"].append(j["性别"])
        if j.get("年龄"):
            pools["年龄"].append(j["年龄"])
        for k in ("视频生产类目", "最近搜索内容", "最近观看的直播"):
            v = j.get(k, [])
            if isinstance(v, list):
                pools[k].extend([x for x in v if x])
    return pools


def _refine_profile_hybrid(profile: dict, pools: dict, rng: random.Random) -> dict:
    """Hybrid mode: keep symbolic backbone, inject small distributional noise."""
    p = dict(profile)
    # Low-rate stochastic refinement, to avoid over-symbolic determinism.
    if rng.random() < 0.15 and pools["性别"]:
        p["性别"] = rng.choice(pools["性别"])
    if rng.random() < 0.20 and pools["年龄"]:
        p["年龄"] = rng.choice(pools["年龄"])

    for key, cap, prob in (
        ("视频生产类目", 5, 0.35),
        ("最近搜索内容", 30, 0.40),
        ("最近观看的直播", 20, 0.30),
    ):
        arr = p.get(key, [])
        if not isinstance(arr, list):
            arr = []
        if pools[key] and rng.random() < prob:
            add_n = max(1, min(3, cap - len(arr)))
            arr = list(arr) + rng.sample(pools[key], min(add_n, len(pools[key])))
        seen = set()
        dedup = []
        for x in arr:
            if isinstance(x, (dict, list)):
                k = json.dumps(x, ensure_ascii=False, sort_keys=True)
            else:
                k = str(x)
            if k in seen:
                continue
            seen.add(k)
            dedup.append(x)
            if len(dedup) >= cap:
                break
        p[key] = dedup
    return p


def _as_list(x: Any) -> list:
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return []
    return list(x)


def _has_profile_sid(row: dict) -> bool:
    v = row.get("inter_user_profile_with_sid")
    return isinstance(v, str) and bool(v.strip())


def _load_parent_pool(df: pd.DataFrame) -> list[int]:
    pool = []
    df0 = df[df["split"] == 0]
    for _, row in df0.iterrows():
        d = row.to_dict()
        if not _has_profile_sid(d):
            continue
        hist = _as_list(d.get("hist_video_pid"))
        if not hist:
            continue
        pool.append(int(d["uid"]))
    return pool


def _load_user(df_indexed: pd.DataFrame, uid: int) -> dict:
    """Full user row for synth_user_xr (hist + behavior masks + parsed profile)."""
    row = df_indexed.loc[uid]
    hist = [int(x) for x in _as_list(row["hist_video_pid"])]
    profile_text = row["inter_user_profile_with_sid"] or ""
    try:
        profile_json = json.loads(profile_text)
        if not isinstance(profile_json, dict):
            profile_json = {}
    except Exception:
        profile_json = {}
    out = {
        "uid": int(uid),
        "hist_video_pid": hist,
        "inter_user_profile_with_sid": profile_text,
        "_profile_json": profile_json,
    }
    n = len(hist)
    for col in BEHAVIOR_COLS_XR:
        vals = _as_list(row.get(col))
        if len(vals) < n:
            vals = vals + [0] * (n - len(vals))
        else:
            vals = vals[:n]
        out[col] = [int(x) for x in vals]
    return out


def _sample_trace_segment(trace: list[int], ratio: float, rng: random.Random) -> list[int]:
    n = len(trace)
    if n == 0:
        return []
    k = max(1, round(n * ratio))
    idx = sorted(rng.sample(range(n), min(k, n)))
    return [trace[i] for i in idx]


def _interleave(a: list[int], b: list[int]) -> list[int]:
    out = []
    ia, ib = 0, 0
    while ia < len(a) or ib < len(b):
        if ia < len(a):
            out.append(a[ia])
            ia += 1
        if ib < len(b):
            out.append(b[ib])
            ib += 1
    return out


def _load_pid2sid() -> dict[int, tuple[int, int, int]]:
    df = pd.read_parquet(PID2SID_PATH)
    return {int(r["new_pid"]): tuple(int(x) for x in r["sid"]) for _, r in df.iterrows()}


def _sid_to_pid_lookup() -> dict[str, list[dict]]:
    with open(SID2PID_PATH) as f:
        return json.load(f)


def _sid_to_pid(sid2pid: dict[str, list[dict]], c0: int, c1: int, c2: int) -> int | None:
    code = c0 * CODE_MULT_1 + c1 * CODE_MULT_2 + c2
    values = sid2pid.get(str(code))
    if not values:
        return None
    best = max(values, key=lambda x: x.get("count_after_downsample", 0))
    return int(best["pid"])


def _pid_to_sid_token(pid2sid: dict[int, tuple[int, int, int]], pid: int) -> str:
    sid = pid2sid.get(int(pid))
    if sid is None:
        return ""
    return SID_FMT.format(c0=sid[0], c1=sid[1], c2=sid[2])


def _build_prompt(
    tokenizer,
    chat_template: str,
    profile_text: str,
    context_pids: list[int],
    pid2sid: dict[int, tuple[int, int, int]],
    max_prompt_tokens: int,
    sid_budget: int = 120,
) -> str:
    """Build prompt with larger context window (no dynamic token truncation)."""
    # Keep this static cap only to avoid pathological ultra-long profiles.
    profile_chars = min(len(profile_text), 12000)
    recent = context_pids[-sid_budget:] if sid_budget > 0 else []
    sid_tokens = []
    for p in recent:
        tok = _pid_to_sid_token(pid2sid, p)
        if tok:
            sid_tokens.append(tok)
    seq = "".join(sid_tokens)
    prof = profile_text[:profile_chars]
    user_msg = (
        f"{prof}\n"
        f"最近序列：{seq if seq else '（无）'}\n"
        "请预测用户接下来会观看的下一个视频。"
    )
    prompt = tokenizer.apply_chat_template(
        [
            {"role": "system", "content": SYSTEM_MSG},
            {"role": "user", "content": user_msg},
        ],
        chat_template=chat_template,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    return prompt + "<|sid_begin|>"


def _build_profile_synth_prompt(alpha: float, profile_a: str, profile_b: str) -> str:
    def _sanitize_input_profile(text: str) -> str:
        t = str(text or "")
        # keep SID tokens and behavior semantics, only strip obvious injected instructions
        for p in INJECTION_PATTERNS:
            t = re.sub(p, "", t, flags=re.IGNORECASE)
        t = re.sub(r"[`#]{2,}", " ", t)
        t = re.sub(r"\s+", " ", t).strip()
        return t

    return PROFILE_SYNTH_PROMPT_TEMPLATE.format(
        alpha=alpha,
        profile_a=_sanitize_input_profile(profile_a),
        profile_b=_sanitize_input_profile(profile_b),
    )


def _sanitize_profile_text(text: str) -> str:
    s = text.strip()
    s = re.sub(r"```(?:json|text)?", "", s)
    s = s.replace("```", "").strip()
    # remove leading instruction/meta echoes if present
    s = re.sub(r"^[^\n。！？]*(A用户|B用户|融合后|请直接输出|仅文本本体)[^\n。！？]*[。！？]?\s*", "", s, flags=re.IGNORECASE)
    s = re.sub(r"^[^\n。！？]*(无需思考|不要输出|内部完成结构化融合)[^\n。！？]*[。！？]?\s*", "", s, flags=re.IGNORECASE)
    # Hard remove comment-related sentences/fields if model leaks them.
    s = re.sub(r"[^\n。！？]*评论[^\n。！？]*[。！？]?", "", s)
    s = re.sub(r'"最近评论的视频"\s*:\s*\[[^\]]*\]\s*,?', "", s)
    s = re.sub(r"\n{2,}", "\n", s).strip()
    return s


def _is_bad_profile_text(text: str) -> bool:
    t = (text or "").strip()
    if not t:
        return True
    if len(t) < 120:
        return True
    bad_echo = re.search(
        r"(无需思考|请直接输出最终的自然语言用户画像文本|仅文本本体|\bassistant\b|\boutput\b|\bno_think\b|A用户|B用户|融合后)",
        t,
        flags=re.IGNORECASE,
    )
    if bad_echo:
        return True
    return False


def _generate_profile_text_vllm(llm, sampling_params, alpha: float, profile_a: str, profile_b: str) -> str:
    prompt = _build_profile_synth_prompt(alpha, profile_a, profile_b)
    out = llm.generate(
        [
            prompt
        ],
        sampling_params,
        use_tqdm=False,
    )
    return _sanitize_profile_text(out[0].outputs[0].text)


def _generate_profile_text_transformers(model, tokenizer, alpha: float, profile_a: str, profile_b: str) -> str:
    prompt = _build_profile_synth_prompt(alpha, profile_a, profile_b)
    inputs = tokenizer([prompt], return_tensors="pt", padding=True, truncation=True, max_length=4096 - 512)
    inputs = {k: v.to(model.device) for k, v in inputs.items()}
    with torch.inference_mode():
        out = model.generate(
            **inputs,
            max_new_tokens=1024,
            do_sample=True,
            top_p=0.9,
            temperature=0.7,
            repetition_penalty=1.05,
            pad_token_id=tokenizer.pad_token_id,
        )
    text = tokenizer.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
    return _sanitize_profile_text(text)


def _generate_next_pid_transformers(
    model,
    tokenizer,
    prompt: str,
    sid2pid: dict[str, list[dict]],
) -> int | None:
    inputs = tokenizer(
        [prompt],
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=4096 - 64,
    )
    inputs = {k: v.to(model.device) for k, v in inputs.items()}
    with torch.inference_mode():
        out = model.generate(
            **inputs,
            max_new_tokens=64,
            do_sample=True,
            top_p=0.95,
            top_k=50,
            temperature=1.0,
            repetition_penalty=1.1,
            pad_token_id=tokenizer.pad_token_id,
        )
    text = tokenizer.decode(out[0][inputs["input_ids"].shape[1]:], skip_special_tokens=False)
    matches = SID_RE.findall(text)
    for c0, c1, c2 in matches:
        pid = _sid_to_pid(sid2pid, int(c0), int(c1), int(c2))
        if pid is not None:
            return pid
    return None


def _generate_next_pid_vllm(
    llm,
    sampling_params,
    prompt: str,
    sid2pid: dict[str, list[dict]],
) -> int | None:
    out = llm.generate([prompt], sampling_params, use_tqdm=False)
    text = out[0].outputs[0].text
    matches = SID_RE.findall(text)
    for c0, c1, c2 in matches:
        pid = _sid_to_pid(sid2pid, int(c0), int(c1), int(c2))
        if pid is not None:
            return pid
    return None


def _generate_trace_mock(
    trace_a: list[int],
    trace_b: list[int],
    alpha: float,
    target_len: int,
    rng: random.Random,
) -> list[int]:
    """Fast fallback when model backend is unavailable."""
    if not trace_a and not trace_b:
        return []
    out = []
    for _ in range(target_len):
        src = trace_a if (rng.random() < alpha and trace_a) or not trace_b else trace_b
        out.append(int(rng.choice(src)))
    return out


def _to_training_format(df_synth: pd.DataFrame) -> pd.DataFrame:
    cols = [
        "uid", "split",
        "hist_video_follow", "hist_video_forward", "hist_video_like", "hist_video_longview", "hist_video_not_interested",
        "hist_video_pid",
        "target_video_follow", "target_video_forward", "target_video_like", "target_video_longview", "target_video_not_interested",
        "target_video_pid",
        "hist_ad_pid", "target_ad_pid", "hist_goods_pid", "target_goods_pid",
        "inter_keyword_to_items", "inter_user_profile_with_pid", "inter_user_profile_with_sid",
        "reco_gsu_caption", "reco_target_caption", "reco_cot",
    ]
    rows = []
    for _, r in df_synth.iterrows():
        n = len(r["trace"])
        zeros = [0] * n
        rows.append(
            {
                "uid": int(r["synth_uid"]),
                "split": 0,
                "hist_video_follow": zeros,
                "hist_video_forward": zeros,
                "hist_video_like": zeros,
                "hist_video_longview": zeros,
                "hist_video_not_interested": zeros,
                "hist_video_pid": [int(x) for x in r["trace"]],
                "target_video_follow": [],
                "target_video_forward": [],
                "target_video_like": [],
                "target_video_longview": [],
                "target_video_not_interested": [],
                "target_video_pid": [],
                "hist_ad_pid": [],
                "target_ad_pid": [],
                "hist_goods_pid": [],
                "target_goods_pid": [],
                "inter_keyword_to_items": None,
                "inter_user_profile_with_pid": None,
                "inter_user_profile_with_sid": r["inter_user_profile_with_sid"],
                "reco_gsu_caption": "",
                "reco_target_caption": "",
                "reco_cot": "",
            }
        )
    out = pd.DataFrame(rows)
    return out[cols]


def _quality_report(df_synth: pd.DataFrame, df_train: pd.DataFrame) -> dict:
    train0 = df_train[df_train["split"] == 0]
    train_hist_len = train0["hist_video_pid"].apply(lambda x: len(_as_list(x)))
    synth_hist_len = df_synth["trace"].apply(len)
    prof_len = df_synth["inter_user_profile_with_sid"].astype(str).str.len()
    return {
        "n_synth": int(len(df_synth)),
        "train_hist_len_mean": float(train_hist_len.mean()),
        "synth_hist_len_mean": float(synth_hist_len.mean()),
        "train_hist_len_p50": float(train_hist_len.median()),
        "synth_hist_len_p50": float(synth_hist_len.median()),
        "synth_profile_len_chars_p50": float(prof_len.median()),
    }


def synthesize_batch(
    n: int,
    alpha: float,
    seed: int,
    out_name: str,
    sample_ratio: float = 0.2,
    backend: str = "mock",
    gpu_memory_utilization: float = 0.95,
    max_model_len: int = 8192,
    model_path: str = DEFAULT_MODEL_PATH,
    profile_gen_mode: str = "llm",
    profile_method: str = "symbolic",
    profile_only: bool = False,
    profile_variant: str = "v2",
    form_ratio: float = 0.5,
) -> tuple[Path, Path, dict]:
    rng = random.Random(seed)
    np.random.seed(seed)

    print("[synth] loading data ...")
    cols = ["uid", "split", "hist_video_pid", "inter_user_profile_with_sid"] + BEHAVIOR_COLS_XR
    df = pd.read_parquet(DATA_PATH, columns=cols)
    parent_pool = _load_parent_pool(df)
    if len(parent_pool) < 2:
        raise RuntimeError("Not enough parent users after has_profile_sid + non-empty-history filtering.")
    print(f"[synth] parent pool size: {len(parent_pool):,}")

    df_indexed = df.set_index("uid", drop=False)
    profile_pools = _build_profile_field_pools(df[df["split"] == 0]) if profile_method == "hybrid" else {}
    su_xr = None
    pid2sid_profile = None
    if profile_gen_mode == "xr":
        print("[synth] loading synth_user_xr module + PID→SID maps for profile …")
        su_xr = _import_synth_user_xr()
        pid2sid_profile = _load_pid2sid_str_for_profile()

    pid2sid_trace: dict[int, tuple[int, int, int]] = {}
    sid2pid: dict[str, list[dict]] = {}
    chat_template = ""
    if backend in ("transformers", "vllm"):
        pid2sid_trace = _load_pid2sid()
        sid2pid = _sid_to_pid_lookup()
        chat_template = CHAT_TEMPLATE_PATH.read_text()
    tokenizer = None
    model = None
    llm = None
    vllm_sp = None
    vllm_sp_profile = None
    if backend == "transformers":
        if AutoTokenizer is None or AutoModelForCausalLM is None or torch is None:
            raise RuntimeError("transformers backend requires torch + transformers to be installed.")
        print(f"[synth] loading model (transformers backend): {model_path}")
        t_model = time.time()
        tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        model = AutoModelForCausalLM.from_pretrained(
            model_path,
            torch_dtype=torch.bfloat16,
            device_map="auto",
            trust_remote_code=True,
        )
        model.eval()
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token_id = tokenizer.eos_token_id
        print(f"[synth] model loaded in {time.time() - t_model:.1f}s")
    elif backend == "vllm":
        if LLM is None or SamplingParams is None:
            raise RuntimeError("vllm backend requires vllm to be installed.")
        print(f"[synth] loading model (vllm backend): {model_path}")
        t_model = time.time()
        llm = LLM(
            model=model_path,
            dtype="bfloat16",
            trust_remote_code=True,
            gpu_memory_utilization=gpu_memory_utilization,
            max_model_len=max_model_len,
        )
        tokenizer = llm.get_tokenizer()
        vllm_sp = SamplingParams(
            max_tokens=64,
            temperature=1.0,
            top_p=0.95,
            top_k=50,
            repetition_penalty=1.1,
        )
        vllm_sp_profile = SamplingParams(
            max_tokens=1024,
            temperature=0.7,
            top_p=0.9,
            repetition_penalty=1.05,
        )
        print(f"[synth] model loaded in {time.time() - t_model:.1f}s")

    if profile_gen_mode == "llm" and backend == "mock":
        raise RuntimeError("profile_gen_mode=llm requires backend=vllm or transformers.")

    rows = []
    t_batch = time.time()
    for i in range(n):
        t_user = time.time()
        uid_a, uid_b = rng.sample(parent_pool, 2)
        user_a = _load_user(df_indexed, uid_a)
        user_b = _load_user(df_indexed, uid_b)

        if profile_gen_mode == "llm":
            profile_text = ""
            for _try in range(2):
                if backend == "vllm":
                    profile_text = _generate_profile_text_vllm(
                        llm,
                        vllm_sp_profile,
                        alpha=alpha,
                        profile_a=user_a.get("inter_user_profile_with_sid", ""),
                        profile_b=user_b.get("inter_user_profile_with_sid", ""),
                    )
                else:
                    profile_text = _generate_profile_text_transformers(
                        model,
                        tokenizer,
                        alpha=alpha,
                        profile_a=user_a.get("inter_user_profile_with_sid", ""),
                        profile_b=user_b.get("inter_user_profile_with_sid", ""),
                    )
                if not _is_bad_profile_text(profile_text):
                    break

            if _is_bad_profile_text(profile_text):
                # hard fallback for robustness: xr profile generator
                if su_xr is None or pid2sid_profile is None:
                    su_xr = _import_synth_user_xr()
                    pid2sid_profile = _load_pid2sid_str_for_profile()
                synth_hist_fb = su_xr.interleave_history(user_a, user_b, alpha=alpha, seed=seed + i)
                synth_hist_fb["_parent_a_was_json"] = bool(user_a.get("_profile_json"))
                synth_hist_fb["_parent_b_was_json"] = bool(user_b.get("_profile_json"))
                persona_fb = su_xr.merge_persona(user_a, user_b, alpha=alpha, seed=seed + i)
                profile_text = su_xr.assemble_rich_profile(
                    persona_fb,
                    synth_hist_fb,
                    pid2sid_profile,
                    seed=seed + i,
                    variant=profile_variant,
                    form_ratio=form_ratio,
                )
                profile_text = _sanitize_profile_text(profile_text)
                profile_new = {"gen_mode": "llm_prompt_fusion_fallback_xr"}
            else:
                profile_new = {"gen_mode": "llm_prompt_fusion"}

            synth_hist = {"hist_video_pid": []}
        else:
            # Profile: synth_user_xr pipeline (rich NL text; SID sections from interleaved hist).
            synth_hist = su_xr.interleave_history(user_a, user_b, alpha=alpha, seed=seed + i)
            synth_hist["_parent_a_was_json"] = bool(user_a.get("_profile_json"))
            synth_hist["_parent_b_was_json"] = bool(user_b.get("_profile_json"))
            persona = su_xr.merge_persona(user_a, user_b, alpha=alpha, seed=seed + i)
            if profile_method == "hybrid":
                persona = _refine_profile_hybrid(
                    persona, profile_pools, random.Random(seed + i + 10007)
                )
            profile_text = su_xr.assemble_rich_profile(
                persona,
                synth_hist,
                pid2sid_profile,
                seed=seed + i,
                variant=profile_variant,
                form_ratio=form_ratio,
            )
            profile_new = persona

        trace_a = user_a["hist_video_pid"]
        trace_b = user_b["hist_video_pid"]
        target_len = int(round((len(trace_a) + len(trace_b)) / 2))

        seg_a = _sample_trace_segment(trace_a, sample_ratio, rng)
        seg_b = _sample_trace_segment(trace_b, sample_ratio, rng)
        seq_seed = _interleave(seg_a, seg_b)
        context = list(seq_seed)
        generated = []

        if profile_only:
            generated = []
            target_len = 0
        elif backend == "mock":
            generated = _generate_trace_mock(trace_a, trace_b, alpha, target_len, rng)
        elif backend == "vllm":
            for step in range(target_len):
                pid = None
                for _try in range(3):
                    prompt = _build_prompt(
                        tokenizer,
                        chat_template,
                        profile_text,
                        context,
                        pid2sid_trace,
                        max_prompt_tokens=max_model_len - 64,
                    )
                    pid = _generate_next_pid_vllm(llm, vllm_sp, prompt, sid2pid)
                    if pid is not None:
                        break
                if pid is None:
                    pid = rng.choice(trace_a if rng.random() < alpha else trace_b)
                generated.append(int(pid))
                context.append(int(pid))
                if (step + 1) % 50 == 0 or (step + 1) == target_len:
                    print(
                        f"[synth][user {i+1}/{n}] gen_step {step+1}/{target_len} "
                        f"(elapsed {time.time() - t_user:.1f}s)"
                    )
        else:
            for step in range(target_len):
                pid = None
                for _try in range(3):
                    prompt = _build_prompt(
                        tokenizer,
                        chat_template,
                        profile_text,
                        context,
                        pid2sid_trace,
                        max_prompt_tokens=max_model_len - 64,
                    )
                    pid = _generate_next_pid_transformers(model, tokenizer, prompt, sid2pid)
                    if pid is not None:
                        break
                if pid is None:
                    pid = rng.choice(trace_a if rng.random() < alpha else trace_b)
                generated.append(int(pid))
                context.append(int(pid))
                if (step + 1) % 50 == 0 or (step + 1) == target_len:
                    print(
                        f"[synth][user {i+1}/{n}] gen_step {step+1}/{target_len} "
                        f"(elapsed {time.time() - t_user:.1f}s)"
                    )

        rows.append(
            {
                "synth_uid": 20_000_000 + i,
                "uid_a": int(uid_a),
                "uid_b": int(uid_b),
                "alpha": float(alpha),
                "sample_ratio": float(sample_ratio),
                "target_len": int(target_len),
                "seed_len": int(len(seq_seed)),
                "inter_user_profile_with_sid": profile_text,
                "profile_persona": profile_new,
                "profile_synth_hist_len": int(len(synth_hist["hist_video_pid"])),
                "trace": generated,  # final trace: generated only, seed discarded
            }
        )
        elapsed = time.time() - t_batch
        rate = (i + 1) / max(elapsed, 1e-6)
        eta = (n - i - 1) / max(rate, 1e-6)
        print(
            f"[synth] user {i+1}/{n} done | target_len={target_len}, seed_len={len(seq_seed)}, "
            f"user_time={time.time() - t_user:.1f}s, total_elapsed={elapsed:.1f}s, ETA={eta:.1f}s"
        )

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUT_DIR / out_name
    df_synth = pd.DataFrame(rows)
    df_synth.to_parquet(out_path, compression="zstd")
    train_like = _to_training_format(df_synth)
    train_like_path = OUT_DIR / out_name.replace(".parquet", "_train_format.parquet")
    train_like.to_parquet(train_like_path, compression="zstd")
    report = _quality_report(df_synth, df)
    print(f"[synth] wrote {out_path}")
    print(f"[synth] wrote {train_like_path}")
    print(f"[synth] quality: {json.dumps(report, ensure_ascii=False)}")
    return out_path, train_like_path, report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, required=True, help="Number of synthetic users.")
    ap.add_argument("--alpha", type=float, default=0.5, help="Profile merge weight for parent A.")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--sample-ratio", type=float, default=0.2, help="Per-parent seed trace sample ratio.")
    ap.add_argument("--out", type=str, default="synth_profile_trace.parquet")
    ap.add_argument("--backend", choices=["mock", "transformers", "vllm"], default="mock")
    ap.add_argument(
        "--profile-gen-mode",
        choices=["llm", "xr"],
        default="llm",
        help="llm: use prompt-based A/B profile synthesis (default); xr: use synth_user_xr pipeline.",
    )
    ap.add_argument(
        "--profile-method",
        choices=["symbolic", "hybrid"],
        default="symbolic",
        help="symbolic=synth_user_xr merge_persona only; hybrid adds small pool noise before assemble_rich_profile.",
    )
    ap.add_argument(
        "--profile-variant",
        choices=["v1", "v2"],
        default="v2",
        help="assemble_rich_profile variant (see synth_user_xr README).",
    )
    ap.add_argument(
        "--form-ratio",
        type=float,
        default=0.5,
        help="v2 only: probability of JSON-form profile vs prose.",
    )
    ap.add_argument("--profile-only", action="store_true", help="Only synthesize profiles; trace fields are empty.")
    ap.add_argument("--gpu-memory-utilization", type=float, default=0.95)
    ap.add_argument("--max-model-len", type=int, default=8192)
    ap.add_argument("--model-path", type=str, default=DEFAULT_MODEL_PATH)
    args = ap.parse_args()

    synthesize_batch(
        n=args.n,
        alpha=args.alpha,
        seed=args.seed,
        out_name=args.out,
        sample_ratio=args.sample_ratio,
        backend=args.backend,
        gpu_memory_utilization=args.gpu_memory_utilization,
        max_model_len=args.max_model_len,
        model_path=args.model_path,
        profile_gen_mode=args.profile_gen_mode,
        profile_method=args.profile_method,
        profile_only=args.profile_only,
        profile_variant=args.profile_variant,
        form_ratio=args.form_ratio,
    )


if __name__ == "__main__":
    main()
