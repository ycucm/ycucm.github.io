# Synth Profile + Trace（training 分布对齐）

本目录提供批量脚本 `synthesize_profile_trace.py`：从训练集（仅 `split=0` 且有 profile+history）抽样父用户，合成新用户的 `inter_user_profile_with_sid` 与 `trace(hist_video_pid)`，并导出与 `onerec_bench_release.parquet` 对齐的 train-format parquet。

## 快速运行

### 只生成 profile（LLM 融合，推荐）

```bash
cd /home/lzq/usersim
export VLLM_USE_V1=0
/home/lzq/miniconda3/envs/house/bin/python3 \
  synth_profile_trace_dist_match/synthesize_profile_trace.py \
  --n 20 \
  --profile-only \
  --backend vllm \
  --profile-gen-mode llm \
  --model-path /home/lzq/usersim/OpenOneRec/models/OneRec-1.7B \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.9 \
  --alpha 0.5 \
  --seed 42 \
  --out profile_only_llm_n20.parquet
```

### profile + trace（真实模型）

```bash
cd /home/lzq/usersim
export VLLM_USE_V1=0
/home/lzq/miniconda3/envs/house/bin/python3 \
  synth_profile_trace_dist_match/synthesize_profile_trace.py \
  --n 20 \
  --backend vllm \
  --profile-gen-mode llm \
  --model-path /home/lzq/usersim/OpenOneRec/models/OneRec-1.7B \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.9 \
  --alpha 0.5 \
  --sample-ratio 0.2 \
  --seed 42 \
  --out synth_llm_trace_n20.parquet
```

### 冒烟（不走模型）

```bash
cd /home/lzq/usersim
python3 synth_profile_trace_dist_match/synthesize_profile_trace.py \
  --n 10 \
  --backend mock \
  --profile-gen-mode xr \
  --sample-ratio 0.2 \
  --seed 42 \
  --out synth_mock_n10.parquet
```

## 当前实现逻辑

- **父池过滤**：`split == 0` 且 `inter_user_profile_with_sid` 非空且 `hist_video_pid` 非空。
- **Profile 合成（默认 LLM）**：
  - 使用给定中文融合 prompt（A/B + alpha）生成自然语言画像。
  - 输入前做注入噪声清理（例如“无需思考/仅文本本体/assistant”等）。
  - 输出后做清理：去代码块、去评论字段、去指令回显与 A/B 元叙述。
  - 质量门控：空文本、过短、回显判坏；自动重试。
  - 重试失败自动回退到 `synth_user_xr` 管线，避免坏样本写入。
- **Profile 备选（XR）**：`interleave_history -> merge_persona -> assemble_rich_profile`。
- **Trace 合成**：
  1) 双父各采 `sample_ratio`（默认 20%）；
  2) 交错成 `seq_seed`；
  3) OpenOneRec 自回归生成目标长度 `round((len(a)+len(b))/2)`；
  4) 最终 `trace` 只保留生成段，`seq_seed` 不写入结果。

## 关键参数

- `--n`：生成用户数量（必填）。
- `--profile-only`：只生成 profile，不生成 trace。
- `--backend {mock,transformers,vllm}`：模型后端。
- `--profile-gen-mode {llm,xr}`：profile 生成方式（默认 `llm`）。
- `--profile-method {symbolic,hybrid}`：仅 XR 模式生效。
- `--sample-ratio`：trace seed 比例（默认 `0.2`）。
- `--max-model-len`：vLLM 上下文长度（默认 `8192`）。
- `--model-path`：模型路径（默认 `OpenOneRec/models/OneRec-1.7B`）。

## 输出文件

默认在 `synth_profile_trace_dist_match/output/` 生成：

- `--out` 指定的主 parquet（含 `synth_uid/uid_a/uid_b/inter_user_profile_with_sid/trace` 等）。
- 同名 `_train_format.parquet`（列对齐 `onerec_bench_release.parquet`）。

## 近期验证（2026-05-06）

使用 `1.7B + vllm + profile-only + n=20 + max_model_len=8192`：

- 基线：`empty=4`, `instruction_echo=5`, `short(<120)=4`
- 优化后：`empty=0`, `instruction_echo=0`, `short(<120)=0`

对应文件：

- `output/profile_only_llm_1p7b_n20_8192.parquet`
- `output/profile_only_llm_1p7b_n20_8192_opt2.parquet`
