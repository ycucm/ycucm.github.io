# Synth Profile + Trace（training 分布对齐）

本目录提供批量脚本 **`synthesize_profile_trace.py`**：从 OpenOneRec bench 数据中抽样父用户，合成新的 **`inter_user_profile_with_sid`** 与 **`hist_video_pid` 形式的 trace**，并可导出与 **`onerec_bench_release.parquet` 相同 schema** 的数据集。

---

## 怎么运行（必读）

### 前置条件

1. **工作目录**：在仓库根目录执行（下面命令假定 **`/home/lzq/usersim`**；若不同请自行替换）。
2. **Python**：系统 `python3` 即可跑 **`mock`** / **`--profile-only`**。要用 **GPU + vLLM** 时建议使用 conda 环境里的 Python（示例：`/home/lzq/miniconda3/envs/house/bin/python3`）。
3. **条数**：生成多少个合成用户，一律用 **`--n <整数>`**（每人一条 profile；不加 `--profile-only` 时每人还有一条 trace）。

### 脚本路径

```text
synth_profile_trace_dist_match/synthesize_profile_trace.py
```

### 输出写到哪里

默认写入：**`synth_profile_trace_dist_match/output/`**  

每次运行会得到两个文件：

- **`--out` 指定的名字**，例如 `foo.parquet`
- 同名 **`foo_train_format.parquet`**（列与训练集 `onerec_bench_release.parquet` 对齐）

---

### 命令 A：只生成 Profile（不调轨迹模型，最快）

把 **`500`** 改成你想要的条数：

```bash
cd /home/lzq/usersim

python3 synth_profile_trace_dist_match/synthesize_profile_trace.py \
  --n 500 \
  --profile-only \
  --backend mock \
  --profile-variant v2 \
  --form-ratio 0.5 \
  --seed 42 \
  --out profiles_n500.parquet
```

---

### 命令 B：Profile + Trace（Mock，不加载 GPU，适合冒烟）

把 **`10`** 改成你想要的条数：

```bash
cd /home/lzq/usersim

python3 synth_profile_trace_dist_match/synthesize_profile_trace.py \
  --n 10 \
  --backend mock \
  --alpha 0.5 \
  --sample-ratio 0.2 \
  --seed 42 \
  --profile-variant v2 \
  --out synth_mock_n10.parquet
```

---

### 命令 C：Profile + Trace（vLLM + 真实 OpenOneRec 模型，需 GPU）

1. 先把 **`--model-path`** 改成你机器上的模型目录（HF 格式权重）。
2. 把 **`--n`** 改成你想要的条数。
3. 建议在能访问 GPU 的终端执行（本示例用 `house` 环境）：

```bash
cd /home/lzq/usersim

export VLLM_USE_V1=0

/home/lzq/miniconda3/envs/house/bin/python3 \
  synth_profile_trace_dist_match/synthesize_profile_trace.py \
  --n 20 \
  --backend vllm \
  --model-path /home/lzq/usersim/OpenOneRec/models/OneRec-1.7B \
  --max-model-len 2048 \
  --gpu-memory-utilization 0.95 \
  --alpha 0.5 \
  --sample-ratio 0.2 \
  --seed 42 \
  --profile-variant v2 \
  --form-ratio 0.5 \
  --out synth_vllm_n20.parquet
```

若显存报错，可先把 **`--gpu-memory-utilization`** 调到 **`0.85`**～**`0.90`**，或把 **`--max-model-len`** 降到 **`1536`** 再试。

---

### 命令 D：Profile + Trace（Transformers 后端，可选）

与 vLLM 二选一；同样需要 CUDA 与较大显存：

```bash
cd /home/lzq/usersim

/home/lzq/miniconda3/envs/house/bin/python3 \
  synth_profile_trace_dist_match/synthesize_profile_trace.py \
  --n 5 \
  --backend transformers \
  --model-path /home/lzq/usersim/OpenOneRec/models/OneRec-1.7B \
  --max-model-len 2048 \
  --alpha 0.5 \
  --sample-ratio 0.2 \
  --seed 42 \
  --out synth_hf_n5.parquet
```

---

### 常用参数速查

| 你想做的事 | 关键参数 |
|------------|----------|
| 指定生成多少用户 | **`--n`**（必填） |
| 只要画像、不要 trace | 加上 **`--profile-only`** |
| trace 用假数据快速跑通 | **`--backend mock`** |
| trace 用真实模型 | **`--backend vllm`** 或 **`--backend transformers`** |
| 换模型目录 | **`--model-path /path/to/model`** |
| 父 A 在 merge 里权重更大 | **`--alpha`**（默认 `0.5`） |
| seed 采样比例（默认 20%） | **`--sample-ratio 0.2`** |

完整参数表见下文 **「命令行参数（完整）」**。

---

## 设计要点（读这一节就够）

| 模块 | 做法 | 说明 |
|------|------|------|
| **Profile** | `synth_user_xr/synth_user/synth_user.py` | `interleave_history` → `merge_persona` → `assemble_rich_profile`，输出**自然语言**画像（与 xr README / `generate_batch.py` 一致）。 |
| **Trace** | 双父各采 `--sample-ratio` → **交错**成 seed → **OpenOneRec 模型**逐步生成 `target_len` 个 PID | Seed **仅作条件**，**不写入**最终 trace。 |
| **刻意分离** | Profile 里的 SID 段落来自 **interleave 的 synth_hist**；最终 trace 来自 **另一套 20% seed + LM**。二者不要求一致，便于分别对齐分布。 |

**父节点池**：`split == 0`，且 `inter_user_profile_with_sid` 非空、`hist_video_pid` 非空（与 embed 侧「有 profile 用户」口径一致，且必须有条历史才能采 trace）。

---

## 依赖数据（本仓库路径）

| 文件 | 用途 |
|------|------|
| `OpenOneRec/data_v1.0/onerec_bench_release.parquet` | 父用户行 |
| `OpenOneRec/data_v1.0/video_ad_pid2sid.parquet` | 视频/广告 PID→SID（profile 文本 + prompt） |
| `OpenOneRec/data_v1.0/product_pid2sid.parquet` | 商品 PID→SID（与 xr `load_pid2sid` 一致） |
| `OpenOneRec/data_v1.0/benchmark_data/sid2pid.json` | 解码模型输出的 SID→PID（trace 生成） |
| `OpenOneRec/benchmarks/benchmark/tasks/v1_0/qwen3_soft_switch.jinja2` | chat template（trace 生成） |

---

## 命令行参数（完整）

| 参数 | 默认 | 含义 |
|------|------|------|
| `--n` | **必填** | 合成用户个数（每人一条 profile；若未 `--profile-only` 则每人还有一条 trace）。 |
| `--alpha` | `0.5` | `interleave_history` / `merge_persona` 中父 A 的权重。 |
| `--seed` | `42` | 随机种子（父节点对、采样、部分随机分支）。 |
| `--sample-ratio` | `0.2` | 每个父用户历史上抽取用于 **trace seed** 的比例（与「20%」对应）。 |
| `--out` | `synth_profile_trace.parquet` | 输出文件名（写在 `output/` 下）。 |
| `--backend` | `mock` | **`mock`**：trace 用父池随机 PID，不调模型（极快）。**`transformers`** / **`vllm`**：真实 OpenOneRec 自回归生成 trace。 |
| `--model-path` | `OpenOneRec/models/OneRec-1.7B` | 生成 trace 的模型目录（HF 格式）。 |
| `--max-model-len` | `2048` | vLLM `max_model_len`。 |
| `--gpu-memory-utilization` | `0.95` | vLLM 显存占用比例。 |
| `--profile-only` | 关 | 只生成 profile，`trace` 为空列表；不调轨迹模型。 |
| `--profile-method` | `symbolic` | **`symbolic`**：纯 xr 管线。**`hybrid`**：在 `merge_persona` 之后、`assemble_rich_profile` 之前增加少量训练池扰动（提高多样性）。 |
| `--profile-variant` | `v2` | `assemble_rich_profile` 的 `v1` / `v2`（见 xr README）。 |
| `--form-ratio` | `0.5` | 仅 `v2`：输出 JSON 形 vs prose 形的概率。 |

可复制运行的完整命令见文档最上方 **「怎么运行（必读）」**（命令 A～D）。

---

## 输出文件

默认目录：**`synth_profile_trace_dist_match/output/`**

| 文件 | 内容 |
|------|------|
| `--out` 指定的 `.parquet` | 明细列见下节 |
| 同名 **`_train_format.parquet`** | 列与 `onerec_bench_release.parquet` **一致**（`uid`, `split`, `hist_video_*`, `inter_user_profile_with_sid`, …），合成用户的 `hist_video_pid` 为生成的 trace，行为列为与长度对齐的全 0（占位）。 |

---

## 明细 Parquet 列说明

脚本写出的主 parquet 通常包含：

| 列 | 含义 |
|------|------|
| `synth_uid` | 合成用户 ID（从 `20000000` 起递增）。 |
| `uid_a`, `uid_b` | 父用户 UID。 |
| `alpha`, `sample_ratio` | 本次使用的 α 与 trace seed 比例。 |
| `target_len` | 目标生成 trace 长度 `round((len(hist_a)+len(hist_b))/2)`。 |
| `seed_len` | 交错 seed 长度（不计入最终 trace）。 |
| `inter_user_profile_with_sid` | **xr `assemble_rich_profile` 生成的完整画像文本**。 |
| `profile_persona` | `merge_persona`（及可选 hybrid）后的结构化 dict。 |
| `profile_synth_hist_len` | `interleave_history` 得到的中间序列长度（用于核对画像侧 history）。 |
| `trace` | **仅模型/mock 生成**的 PID 列表（不含 seed）。 |

---

## Profile：与 `synth_user_xr` 对齐

实现方式：运行时 **`importlib` 加载** `synth_user_xr/synth_user/synth_user.py`（勿依赖另一套手写 JSON merge）。

流程简述：

1. **`interleave_history(A,B,α)`** → `synth_hist`（供画像里点赞/转发/关注等 **SID 段落**）。
2. **`merge_persona(A,B,α)`**。
3. **`assemble_rich_profile(persona, synth_hist, pid2sid, seed, variant, form_ratio)`**。

PID→SID 字符串表由本仓库 `video_ad_pid2sid` + `product_pid2sid` 构建，语义与 xr **`load_pid2sid`** 一致。

---

## Trace：算法步骤

1. 从父池随机抽 **两个不同 UID**（有放回地重复配对）。
2. `target_len = round((len(P1.hist) + len(P2.hist)) / 2)`。
3. 各父 `hist_video_pid` 上随机采 **`sample_ratio` 比例**的 PID，按索引有序以保持局部顺序，再 **交错** 成 `seq_seed`。
4. 用 **profile 文本 + 当前已生成前缀（初始为 seed）** 拼 prompt，模型生成下一个视频 SID，再映射为 PID；重复直至凑满 `target_len`。
5. **最终 parquet 中的 `trace` 仅为生成段**，不包含 `seq_seed`。

**性能**：`backend=vllm/transformers` 时对每个用户会做 **约 `target_len` 次**前向生成；父用户很长时会慢，可先减小 `--n` 或换更小模型试跑。

---

## 与 Embed 评估对齐（可选）

若要对合成 profile 做分布检验，建议沿用 **`synth_user_xr/embed`** 管线（profile-only、同层池化），例如：

- 将合成结果整理成含 `synth_uid` + `inter_user_profile_with_sid` 的 parquet；
- 使用项目中的 **`embed/run_synth.py`** 抽向量；
- 与 real working set 用 **`embed/eval_synth.py`** 比较（MMD / AUC 等）。

具体路径若在其他机器上需按 `OPENONEREC_ROOT` 改写（参见 `OpenOneRec/docs/MIGRATION_SYNTH_SFT_EVAL.md`）。

---

## 质量检查建议

1. **Profile**：抽样人工读几条；JSON 可解析率；与真实 profile 长度分布对比。
2. **Trace**：长度分布是否在父均值附近；PID 是否大量重复或无效。
3. **一致性**：画像中的「点赞 SID」来自 **interleave 历史**，与最终 **LM trace** 不一定一致——若业务要求强一致，需改管线（例如用生成 trace 回填画像 SID 段）。
4. **泄漏**：避免把父用户整段历史原样当作合成标签用于同一 split 训练。

---

## 文件清单

| 路径 | 说明 |
|------|------|
| `synthesize_profile_trace.py` | 主入口 |
| `README.md` | 本文档 |
| `output/` | 默认输出目录（运行后生成） |
