#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch

from eval_ope_metrics_onerec8b import ALGOS, evaluate_simulator, summarize
from run_rl_benchmark import load_catalog
from run_rl4rs_baseline_benchmark import item_embeddings
from train_rl4rs_baseline import RL4RSGRUSimulator


@torch.inference_mode()
def score_rl4rs(model, h_sid, h_fb, cand_sid, device, batch_size: int):
    scores = []
    for i in range(0, len(cand_sid), batch_size):
        sid = torch.from_numpy(cand_sid[i : i + batch_size]).long().to(device)
        hsid = torch.from_numpy(np.repeat(h_sid[None], len(sid), axis=0)).long().to(device)
        hfb = torch.from_numpy(np.repeat(h_fb[None], len(sid), axis=0)).float().to(device)
        scores.extend(torch.sigmoid(model(hsid, hfb, sid)).float().cpu().numpy().tolist())
    return np.asarray(scores, dtype=np.float32)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--simulator_ckpt", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_rl4rs_baseline/simulator/best_rl4rs_gru.pt"))
    parser.add_argument("--output", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_rl4rs_baseline/ope_metrics_rl4rs_gru.json"))
    parser.add_argument("--eval_users", type=int, default=48)
    parser.add_argument("--candidate_pool", type=int, default=256)
    parser.add_argument("--catalog_items", type=int, default=5000)
    parser.add_argument("--k", type=int, default=10)
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument("--score_batch_size", type=int, default=256)
    parser.add_argument("--behavior_temp", type=float, default=0.25)
    parser.add_argument("--sid_dim", type=int, default=64)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seed", type=int, default=619607)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(args.cuda)

    hist_sid = np.load(args.cache_dir / "hist_sid.npy", mmap_mode="r")
    hist_fb = np.load(args.cache_dir / "hist_feedback.npy", mmap_mode="r")
    rng = np.random.default_rng(args.seed)
    row_ids = rng.choice(np.arange(len(hist_sid)), size=args.eval_users, replace=False)
    rows = [(np.array(hist_sid[i], copy=True), np.array(hist_fb[i], copy=True)) for i in row_ids]

    model = RL4RSGRUSimulator(args.sid_dim, args.hidden_dim).to(device)
    ckpt = torch.load(args.simulator_ckpt, map_location=device, weights_only=False)
    model.load_state_dict(ckpt["model"])
    model.eval()
    catalog_sid_t = load_catalog(args.cache_dir, args.catalog_items, args.seed)
    catalog_sid = catalog_sid_t.cpu().numpy()
    catalog_emb = item_embeddings(model, catalog_sid_t, device)

    def score_fn(h_sid, h_fb, cand_sid):
        return score_rl4rs(model, h_sid, h_fb, cand_sid, device, args.score_batch_size)

    all_rows = []
    merged = {algo: {"ndcg": [], "kl": [], "ess": []} for algo in ALGOS}
    for s in range(args.seeds):
        part = evaluate_simulator(args, "RL4RS-GRU", score_fn, catalog_sid, catalog_emb, rows, args.seed + s)
        for algo in ALGOS:
            for metric in ["ndcg", "kl", "ess"]:
                merged[algo][metric].extend(part[algo][metric])
    for algo in ALGOS:
        ndcg_m, ndcg_s = summarize(merged[algo]["ndcg"])
        kl_m, kl_s = summarize(merged[algo]["kl"])
        ess_m, ess_s = summarize(merged[algo]["ess"])
        all_rows.append(
            {
                "algorithm": algo,
                "simulator": "RL4RS-GRU",
                "nDCG@10_mean": ndcg_m,
                "nDCG@10_std": ndcg_s,
                "action_KL_mean": kl_m,
                "action_KL_std": kl_s,
                "ESS_mean": ess_m,
                "ESS_std": ess_s,
            }
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    config = {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()}
    args.output.write_text(json.dumps({"config": config, "rows": all_rows}, indent=2), encoding="utf-8")
    print(json.dumps(all_rows, indent=2))


if __name__ == "__main__":
    main()
