#!/usr/bin/env python3
"""OPE metrics for the Qwen3-0.6B DGDPO-style RecIF simulator."""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch

from eval_ope_metrics_onerec8b import ALGOS, evaluate_simulator, summarize
from run_qwen3_dgdpo_recif import Qwen3DGDPOScorer
from run_rl_on_onerec_simulator import load_catalog


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--model_dir", type=Path, default=Path("/opt/gensim/models/Qwen3-0.6B"))
    parser.add_argument("--output", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_qwen3_dgdpo/ope_metrics_qwen3_dgdpo.json"))
    parser.add_argument("--eval_users", type=int, default=48)
    parser.add_argument("--candidate_pool", type=int, default=256)
    parser.add_argument("--catalog_items", type=int, default=5000)
    parser.add_argument("--k", type=int, default=10)
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument("--score_batch_size", type=int, default=32)
    parser.add_argument("--max_prompt_len", type=int, default=1024)
    parser.add_argument("--behavior_temp", type=float, default=0.25)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seed", type=int, default=619607)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(args.cuda)

    hist_sid = np.load(args.cache_dir / "hist_sid.npy", mmap_mode="r")
    hist_fb = np.load(args.cache_dir / "hist_feedback.npy", mmap_mode="r")
    rng = np.random.default_rng(args.seed)
    row_ids = rng.choice(np.arange(len(hist_sid)), size=args.eval_users, replace=False)
    rows = [(np.array(hist_sid[i], copy=True), np.array(hist_fb[i], copy=True)) for i in row_ids]

    scorer = Qwen3DGDPOScorer(args.model_dir, device, args.max_prompt_len, args.score_batch_size)
    catalog_sid = load_catalog(args.cache_dir, args.catalog_items, args.seed)
    catalog_emb = scorer.item_embeddings(catalog_sid, 128, args.seed)

    merged = {algo: {"ndcg": [], "kl": [], "ess": []} for algo in ALGOS}
    for s in range(args.seeds):
        part = evaluate_simulator(args, "DGDPO-Qwen3-0.6B", scorer.score, catalog_sid, catalog_emb, rows, args.seed + s)
        for algo in ALGOS:
            for metric in ["ndcg", "kl", "ess"]:
                merged[algo][metric].extend(part[algo][metric])

    all_rows = []
    for algo in ALGOS:
        ndcg_m, ndcg_s = summarize(merged[algo]["ndcg"])
        kl_m, kl_s = summarize(merged[algo]["kl"])
        ess_m, ess_s = summarize(merged[algo]["ess"])
        all_rows.append(
            {
                "algorithm": algo,
                "simulator": "DGDPO-Qwen3-0.6B",
                "nDCG@10_mean": ndcg_m,
                "nDCG@10_std": ndcg_s,
                "action_KL_mean": kl_m,
                "action_KL_std": kl_s,
                "ESS_mean": ess_m,
                "ESS_std": ess_s,
            }
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    config = {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()}
    config["device"] = str(device)
    args.output.write_text(json.dumps({"config": config, "rows": all_rows}, indent=2), encoding="utf-8")
    print(json.dumps(all_rows, indent=2))


if __name__ == "__main__":
    main()
