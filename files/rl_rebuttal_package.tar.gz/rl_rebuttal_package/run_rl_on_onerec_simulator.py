#!/usr/bin/env python3
"""Evaluate RL algorithms with OneRec-1.7B-Pro as the user simulator."""

from __future__ import annotations

import argparse
import json
import random
from collections import deque
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import trange
from transformers import AutoModelForCausalLM, AutoTokenizer

from train_simulator import INTERACTIONS, SID_PAD


SECTION_NAMES = {
    "longview": "用户长时观看过以下内容：",
    "like": "用户喜欢的内容：",
    "follow": "作者被用户关注的内容：",
    "forward": "用户向他人推荐的内容：",
    "not_interested": "用户不感兴趣的内容：",
}


def sid_text(sid: tuple[int, int, int]) -> str:
    return f"<|sid_begin|><s_a_{sid[0]}><s_b_{sid[1]}><s_c_{sid[2]}><|sid_end|>"


def load_catalog(cache_dir: Path, max_items: int, seed: int) -> np.ndarray:
    target_sid = np.load(cache_dir / "target_sid.npy", mmap_mode="r")
    labels = np.load(cache_dir / "labels.npy", mmap_mode="r")
    uniq, first_idx = np.unique(target_sid, axis=0, return_index=True)
    if max_items > 0 and len(uniq) > max_items:
        rng = np.random.default_rng(seed)
        pos = first_idx[np.asarray(labels[first_idx]) == 1]
        rand = rng.choice(np.arange(len(uniq)), size=max_items, replace=False)
        keep = np.unique(np.concatenate([rand, pos[: max_items // 4]]))[:max_items]
        uniq = uniq[keep]
    return np.asarray(uniq, dtype=np.int64)


class OneRecScorer:
    def __init__(self, model_dir: Path, device: torch.device, max_prompt_len: int, batch_size: int):
        self.device = device
        self.batch_size = batch_size
        self.max_prompt_len = max_prompt_len
        self.tokenizer = AutoTokenizer.from_pretrained(model_dir, trust_remote_code=True, local_files_only=True)
        template_path = Path("/opt/gensim/OpenOneRec/benchmarks/benchmark/tasks/v1_0/qwen3_soft_switch.jinja2")
        if template_path.exists():
            self.tokenizer.chat_template = template_path.read_text(encoding="utf-8")
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.padding_side = "left"
        self.model = AutoModelForCausalLM.from_pretrained(
            model_dir,
            torch_dtype=torch.float16 if device.type == "cuda" else torch.float32,
            trust_remote_code=True,
            local_files_only=True,
        ).to(device)
        self.model.eval()
        self.yes_id = self.tokenizer.encode("是", add_special_tokens=False)[0]
        self.no_id = self.tokenizer.encode("否", add_special_tokens=False)[0]

    def item_token_ids(self, sid: tuple[int, int, int]) -> list[int]:
        return [
            self.tokenizer.convert_tokens_to_ids(f"<s_a_{sid[0]}>"),
            self.tokenizer.convert_tokens_to_ids(f"<s_b_{sid[1]}>"),
            self.tokenizer.convert_tokens_to_ids(f"<s_c_{sid[2]}>"),
        ]

    def item_embeddings(self, catalog_sid: np.ndarray, out_dim: int, seed: int) -> torch.Tensor:
        emb = self.model.get_input_embeddings().weight.detach()
        rows = []
        for sid_arr in catalog_sid:
            ids = torch.tensor(self.item_token_ids(tuple(int(x) for x in sid_arr)), device=emb.device)
            rows.append(emb.index_select(0, ids).mean(dim=0).float().cpu())
        item_emb = torch.stack(rows)
        if out_dim and out_dim < item_emb.shape[-1]:
            gen = torch.Generator().manual_seed(seed)
            proj = torch.randn(item_emb.shape[-1], out_dim, generator=gen) / (item_emb.shape[-1] ** 0.5)
            item_emb = item_emb @ proj
        return F.normalize(item_emb, dim=-1)

    def build_prompt(self, h_sid: np.ndarray, h_fb: np.ndarray, candidate_sid: tuple[int, int, int]) -> str:
        sections = []
        for k, name in enumerate(INTERACTIONS):
            vals = []
            for sid, fb in zip(h_sid, h_fb):
                if sid[0] == SID_PAD or fb[k] <= 0:
                    continue
                vals.append(sid_text(tuple(int(x) for x in sid)))
            if vals:
                sections.append(SECTION_NAMES[name] + "".join(vals[-10:]))
        if not sections:
            sections.append("用户暂无明显互动历史。")
        user = (
            "用户的内容互动历史：\n"
            + "\n".join(sections)
            + f"\n用户会花时间仔细观看视频{sid_text(candidate_sid)}吗？你的回答只需包含\"是\"或\"否\"。"
        )
        messages = [
            {"role": "system", "content": "你是一个内容推荐专家，擅长分析用户的互动模式，预测用户的内容偏好。"},
            {"role": "user", "content": user},
        ]
        return self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )

    @torch.inference_mode()
    def score(self, h_sid: np.ndarray, h_fb: np.ndarray, candidate_sids: np.ndarray) -> np.ndarray:
        scores = []
        prompts = [self.build_prompt(h_sid, h_fb, tuple(int(x) for x in sid)) for sid in candidate_sids]
        for i in range(0, len(prompts), self.batch_size):
            batch = prompts[i : i + self.batch_size]
            toks = self.tokenizer(
                batch,
                padding=True,
                truncation=True,
                max_length=self.max_prompt_len,
                return_tensors="pt",
            ).to(self.device)
            out = self.model(**toks)
            if self.tokenizer.padding_side == "left":
                last = torch.full((len(batch),), toks["input_ids"].shape[1] - 1, device=self.device, dtype=torch.long)
            else:
                last = toks["attention_mask"].sum(dim=1) - 1
            logits = out.logits[torch.arange(len(batch), device=self.device), last]
            yn = logits[:, [self.yes_id, self.no_id]].float()
            yn = torch.nan_to_num(yn, nan=0.0, posinf=50.0, neginf=-50.0).clamp(-50.0, 50.0)
            prob = torch.softmax(yn, dim=-1)[:, 0]
            prob = torch.nan_to_num(prob, nan=0.5, posinf=1.0, neginf=0.0).clamp(0.0, 1.0)
            scores.extend(prob.detach().cpu().numpy().tolist())
        return np.asarray(scores, dtype=np.float32)


class OneRecEnv:
    def __init__(
        self,
        scorer,
        cache_dir: Path,
        catalog_sid,
        catalog_emb,
        max_depth: int,
        slate_size: int,
        seed: int,
        rerank_pool: int,
    ):
        self.scorer = scorer
        self.hist_sid = np.load(cache_dir / "hist_sid.npy", mmap_mode="r")
        self.hist_feedback = np.load(cache_dir / "hist_feedback.npy", mmap_mode="r")
        self.catalog_sid = catalog_sid
        self.catalog_emb = catalog_emb
        self.max_depth = max_depth
        self.slate_size = slate_size
        self.rerank_pool = max(slate_size, rerank_pool)
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self):
        self.row = int(self.rng.integers(0, len(self.hist_sid)))
        self.h_sid = np.array(self.hist_sid[self.row], copy=True)
        self.h_fb = np.array(self.hist_feedback[self.row], copy=True)
        self.depth = 0
        return self.state()

    def state(self):
        valid = self.h_sid[:, 0] != SID_PAD
        if not valid.any():
            return torch.zeros(self.catalog_emb.shape[-1])
        sid_to_idx = {tuple(map(int, sid)): i for i, sid in enumerate(self.catalog_sid.tolist())}
        vecs = []
        weights = []
        for sid, fb in zip(self.h_sid[valid], self.h_fb[valid]):
            idx = sid_to_idx.get(tuple(map(int, sid)))
            if idx is None:
                continue
            vecs.append(self.catalog_emb[idx])
            weights.append(1.0 + float(fb[0]) + 0.5 * float(fb[1]) - 0.5 * float(fb[4]))
        if not vecs:
            return torch.zeros(self.catalog_emb.shape[-1])
        mat = torch.stack(vecs)
        w = torch.tensor(weights).clamp_min(0.1).unsqueeze(-1)
        return F.normalize((mat * w).sum(dim=0) / w.sum(), dim=-1)

    def topk_by_action(self, action, k=None):
        k = k or self.slate_size
        q = F.normalize(action.view(1, -1), dim=-1).cpu()
        scores = (self.catalog_emb @ q.T).squeeze(-1)
        return torch.topk(scores, k=min(k, len(scores))).indices

    def step(self, action):
        pool_idx = self.topk_by_action(action, self.rerank_pool)
        pool = self.catalog_sid[pool_idx.numpy()]
        pool_probs = self.scorer.score(self.h_sid, self.h_fb, pool)
        keep = np.argsort(-pool_probs)[: self.slate_size]
        idx = pool_idx[keep]
        cand = pool[keep]
        probs = pool_probs[keep]
        reward = float(np.mean(probs))
        chosen_pos = int(np.argmax(probs))
        chosen_sid = cand[chosen_pos].astype(np.int32)
        fb = np.zeros((len(INTERACTIONS),), dtype=np.float32)
        fb[0] = 1.0 if self.rng.random() < float(probs[chosen_pos]) else 0.0
        self.h_sid = np.concatenate([self.h_sid[1:], chosen_sid[None]], axis=0)
        self.h_fb = np.concatenate([self.h_fb[1:], fb[None]], axis=0)
        self.depth += 1
        done = self.depth >= self.max_depth or (self.depth > 3 and self.rng.random() > float(probs[chosen_pos]))
        return self.state(), reward, done, {"items": idx.numpy().tolist(), "probs": probs.tolist()}


class Replay:
    def __init__(self, cap=50000):
        self.buf = deque(maxlen=cap)

    def push(self, *x):
        self.buf.append(x)

    def sample(self, n):
        batch = random.sample(self.buf, n)
        return [torch.stack([b[i] if torch.is_tensor(b[i]) else torch.tensor(b[i]) for b in batch]) for i in range(len(batch[0]))]

    def __len__(self):
        return len(self.buf)


class Actor(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(dim, 256), nn.ReLU(), nn.Linear(256, 256), nn.ReLU(), nn.Linear(256, dim))

    def forward(self, s):
        return self.net(s)


class Critic(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.q = nn.Sequential(nn.Linear(dim * 2, 256), nn.ReLU(), nn.Linear(256, 256), nn.ReLU(), nn.Linear(256, 1))

    def forward(self, s, a):
        return self.q(torch.cat([s, a], dim=-1)).squeeze(-1)


class A2CPolicy(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.actor = Actor(dim)
        self.value = nn.Sequential(nn.Linear(dim, 256), nn.ReLU(), nn.Linear(256, 1))

    def forward(self, s):
        return self.actor(s), self.value(s).squeeze(-1)


def evaluate_policy(env, actor, episodes: int, algo: str, device):
    depths, avg_rewards, total_rewards, coverage, ilds = [], [], [], [], []
    for _ in range(episodes):
        s, done = env.reset(), False
        rewards, exposed, ild_ep = [], set(), []
        while not done:
            with torch.no_grad():
                a = actor(s.to(device).unsqueeze(0)).squeeze(0).detach().cpu()
            ns, r, done, info = env.step(a)
            rewards.append(r)
            exposed.update(info["items"])
            emb = env.catalog_emb[info["items"]]
            sim = emb @ emb.T
            if len(emb) > 1:
                ild_ep.append(float((1 - sim).sum() / (len(emb) * (len(emb) - 1))))
            s = ns
        depths.append(len(rewards))
        avg_rewards.append(float(np.mean(rewards)))
        total_rewards.append(float(np.sum(rewards)))
        coverage.append(len(exposed))
        ilds.append(float(np.mean(ild_ep)) if ild_ep else 0.0)
    return {"algorithm": algo, "depth": float(np.mean(depths)), "average_reward": float(np.mean(avg_rewards)), "total_reward": float(np.mean(total_rewards)), "coverage": float(np.mean(coverage)), "ild": float(np.mean(ilds))}


def train_a2c(env, dim, args, device, supervised=False):
    policy = A2CPolicy(dim).to(device)
    opt = torch.optim.Adam(policy.parameters(), lr=3e-4)
    gamma = 0.95
    for _ in trange(args.train_episodes, desc="SA2C" if supervised else "A2C"):
        states, actions, rewards, values = [], [], [], []
        s, done = env.reset(), False
        while not done:
            st = s.to(device)
            mean, value = policy(st.unsqueeze(0))
            dist = torch.distributions.Normal(mean.squeeze(0), torch.ones_like(mean.squeeze(0)) * 0.2)
            a = dist.sample()
            ns, r, done, _ = env.step(a.detach().cpu())
            states.append(st)
            actions.append(a)
            rewards.append(r)
            values.append(value.squeeze(0))
            s = ns
        ret, returns = 0.0, []
        for r in reversed(rewards):
            ret = r + gamma * ret
            returns.append(ret)
        returns = torch.tensor(list(reversed(returns)), device=device)
        values_t = torch.stack(values)
        adv = returns - values_t.detach()
        means, vals = policy(torch.stack(states))
        logp = -((torch.stack(actions) - means) ** 2).mean(dim=-1)
        loss = -(logp * adv).mean() + F.mse_loss(vals, returns)
        if supervised:
            loss = loss + 0.05 * means.norm(dim=-1).mean()
        opt.zero_grad()
        loss.backward()
        opt.step()
    return policy.actor


def train_td3_like(env, dim, args, device, hac=False):
    actor, actor_t = Actor(dim).to(device), Actor(dim).to(device)
    critic1, critic2 = Critic(dim).to(device), Critic(dim).to(device)
    critic1_t, critic2_t = Critic(dim).to(device), Critic(dim).to(device)
    actor_t.load_state_dict(actor.state_dict())
    critic1_t.load_state_dict(critic1.state_dict())
    critic2_t.load_state_dict(critic2.state_dict())
    opt_a = torch.optim.Adam(actor.parameters(), lr=3e-4)
    opt_c = torch.optim.Adam(list(critic1.parameters()) + list(critic2.parameters()), lr=3e-4)
    replay, gamma, tau = Replay(), 0.95, 0.01
    for ep in trange(args.train_episodes, desc="HAC" if hac else "TD3"):
        s, done = env.reset(), False
        while not done:
            with torch.no_grad():
                noise = torch.randn(dim) * (0.3 if ep < args.train_episodes // 2 else 0.1)
                a = actor(s.to(device).unsqueeze(0)).squeeze(0).cpu() + noise
                if hac:
                    nearest = env.topk_by_action(a, 1)[0]
                    a = env.catalog_emb[int(nearest)]
            ns, r, done, _ = env.step(a)
            replay.push(s, a.float(), torch.tensor(r).float(), ns, torch.tensor(float(done)))
            s = ns
            if len(replay) < args.batch_size:
                continue
            sb, ab, rb, nsb, db = [x.to(device).float() for x in replay.sample(args.batch_size)]
            with torch.no_grad():
                na = actor_t(nsb) + torch.randn_like(ab).clamp(-0.1, 0.1)
                target = rb + gamma * (1 - db) * torch.min(critic1_t(nsb, na), critic2_t(nsb, na))
            loss_c = F.mse_loss(critic1(sb, ab), target) + F.mse_loss(critic2(sb, ab), target)
            opt_c.zero_grad()
            loss_c.backward()
            opt_c.step()
            if ep % 2 == 0:
                loss_a = -critic1(sb, actor(sb)).mean()
                opt_a.zero_grad()
                loss_a.backward()
                opt_a.step()
                for net, tgt in [(actor, actor_t), (critic1, critic1_t), (critic2, critic2_t)]:
                    for p, tp in zip(net.parameters(), tgt.parameters()):
                        tp.data.mul_(1 - tau).add_(tau * p.data)
    return actor


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--model_dir", type=Path, default=Path("/opt/gensim/models/OneRec-1.7B-pro"))
    parser.add_argument("--output", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_onerec_simulator/rl_metrics_onerec_simulator.json"))
    parser.add_argument("--catalog_items", type=int, default=1000)
    parser.add_argument("--state_dim", type=int, default=128)
    parser.add_argument("--slate_size", type=int, default=5)
    parser.add_argument("--rerank_pool", type=int, default=5)
    parser.add_argument("--max_depth", type=int, default=10)
    parser.add_argument("--train_episodes", type=int, default=30)
    parser.add_argument("--eval_episodes", type=int, default=20)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--score_batch_size", type=int, default=8)
    parser.add_argument("--max_prompt_len", type=int, default=1536)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seed", type=int, default=619607)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(args.cuda)

    scorer = OneRecScorer(args.model_dir, device, args.max_prompt_len, args.score_batch_size)
    catalog_sid = load_catalog(args.cache_dir, args.catalog_items, args.seed)
    catalog_emb = scorer.item_embeddings(catalog_sid, args.state_dim, args.seed)
    env = OneRecEnv(
        scorer,
        args.cache_dir,
        catalog_sid,
        catalog_emb,
        args.max_depth,
        args.slate_size,
        args.seed,
        args.rerank_pool,
    )
    dim = catalog_emb.shape[-1]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    results = []
    for name, trainer in [
        ("TD3", lambda: train_td3_like(env, dim, args, device, hac=False)),
        ("A2C", lambda: train_a2c(env, dim, args, device, supervised=False)),
        ("SA2C", lambda: train_a2c(env, dim, args, device, supervised=True)),
        ("HAC", lambda: train_td3_like(env, dim, args, device, hac=True)),
    ]:
        actor = trainer()
        result = evaluate_policy(env, actor, args.eval_episodes, name, device)
        results.append(result)
        print(json.dumps(result, ensure_ascii=False))
        args.output.write_text(json.dumps(results, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
