#!/usr/bin/env python3
"""Train a KuaiSim-style longview simulator on RecIF-Bench.

The OpenOneRec label_pred benchmark evaluates AUC for whether a candidate video
will be long-viewed. This script trains the simulator on the same target:
target_video_longview.
"""

from __future__ import annotations

import argparse
import json
import re
import random
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm


INTERACTIONS = ["longview", "like", "follow", "forward", "not_interested"]
SID_PAD = 8192


def as_list(value) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if hasattr(value, "tolist"):
        return value.tolist()
    return list(value)


def safe_binary(value, n: int) -> list[int]:
    vals = as_list(value)
    if len(vals) < n:
        vals = vals + [0] * (n - len(vals))
    return [0 if pd.isna(v) else int(v) for v in vals[:n]]


SID_RE = re.compile(r"<s_a_(\d+)><s_b_(\d+)><s_c_(\d+)>")


def split_name(uid: int, val_user_percent: int) -> str:
    if val_user_percent <= 0:
        return "train"
    return "val" if uid % 100 < val_user_percent else "train"


@dataclass
class BuildStats:
    users: int
    samples: int
    train_samples: int
    val_samples: int
    test_samples: int
    positives: int
    item_vocab_size: int
    max_hist_len: int


def collect_needed_pids(df: pd.DataFrame, max_hist_len: int) -> set[int]:
    pids: set[int] = set()
    for row in tqdm(df.itertuples(index=False), total=len(df), desc="collect pids"):
        hist = as_list(row.hist_video_pid)[-max_hist_len:]
        target = as_list(row.target_video_pid)
        pids.update(int(x) for x in hist if not pd.isna(x))
        pids.update(int(x) for x in target if not pd.isna(x))
    return pids


def load_sid_map(pid2sid_path: Path, needed_pids: set[int]) -> dict[int, tuple[int, int, int]]:
    mapping_df = pd.read_parquet(pid2sid_path)
    mapping_df = mapping_df[mapping_df["pid"].isin(needed_pids)]
    sid_map: dict[int, tuple[int, int, int]] = {}
    for pid, sid in tqdm(zip(mapping_df["pid"], mapping_df["sid"]), total=len(mapping_df), desc="sid map"):
        vals = as_list(sid)
        if len(vals) >= 3:
            sid_map[int(pid)] = (int(vals[0]), int(vals[1]), int(vals[2]))
    return sid_map


def build_cache(args: argparse.Namespace) -> BuildStats:
    out = args.cache_dir
    out.mkdir(parents=True, exist_ok=True)
    cols = ["uid", "hist_video_pid", "target_video_pid"]
    cols += [f"hist_video_{x}" for x in INTERACTIONS]
    cols += [f"target_video_{x}" for x in INTERACTIONS]
    df = pd.read_parquet(args.recif_parquet, columns=cols)
    df = df[df["hist_video_pid"].notna() & df["target_video_pid"].notna()].reset_index(drop=True)
    if args.max_users > 0 and args.max_users < len(df):
        df = df.sample(args.max_users, random_state=args.seed).sort_values("uid").reset_index(drop=True)

    needed = collect_needed_pids(df, args.max_hist_len)
    sid_map = load_sid_map(args.video_pid2sid_parquet, needed)

    hist_sid, hist_fb, hist_len = [], [], []
    target_sid, labels, row_index, splits = [], [], [], []
    users = []
    skipped = 0
    for ridx, row in tqdm(enumerate(df.itertuples(index=False)), total=len(df), desc="build arrays"):
        uid = int(row.uid)
        hist_pids = as_list(row.hist_video_pid)[-args.max_hist_len:]
        target_pids = as_list(row.target_video_pid)[: args.max_targets_per_user]
        if not hist_pids or not target_pids:
            skipped += 1
            continue
        h_len = min(len(hist_pids), args.max_hist_len)
        h_sid = np.full((args.max_hist_len, 3), SID_PAD, dtype=np.int32)
        h_fb = np.zeros((args.max_hist_len, len(INTERACTIONS)), dtype=np.float32)
        offset = args.max_hist_len - h_len
        raw_hist_len = len(as_list(row.hist_video_pid))
        hist_start = max(0, raw_hist_len - h_len)
        for j, pid in enumerate(hist_pids[-h_len:]):
            h_sid[offset + j] = sid_map.get(int(pid), (SID_PAD, SID_PAD, SID_PAD))
        for k, name in enumerate(INTERACTIONS):
            vals = safe_binary(getattr(row, f"hist_video_{name}"), raw_hist_len)[hist_start : hist_start + h_len]
            h_fb[offset : offset + h_len, k] = vals

        user_slot = len(users)
        users.append(uid)
        hist_sid.append(h_sid)
        hist_fb.append(h_fb)
        hist_len.append(h_len)
        target_labels = safe_binary(row.target_video_longview, len(as_list(row.target_video_pid)))[: len(target_pids)]
        for pid, label in zip(target_pids, target_labels):
            sid = sid_map.get(int(pid))
            if sid is None:
                continue
            target_sid.append(sid)
            labels.append(int(label))
            row_index.append(user_slot)
            splits.append(split_name(uid, args.val_user_percent))

    hist_sid_arr = np.asarray(hist_sid, dtype=np.int32)
    hist_fb_arr = np.asarray(hist_fb, dtype=np.float32)
    hist_len_arr = np.asarray(hist_len, dtype=np.int32)
    target_sid_arr = np.asarray(target_sid, dtype=np.int32)
    labels_arr = np.asarray(labels, dtype=np.float32)
    row_index_arr = np.asarray(row_index, dtype=np.int32)
    split_arr = np.asarray(splits)

    np.save(out / "hist_sid.npy", hist_sid_arr)
    np.save(out / "hist_feedback.npy", hist_fb_arr)
    np.save(out / "hist_len.npy", hist_len_arr)
    np.save(out / "target_sid.npy", target_sid_arr)
    np.save(out / "labels.npy", labels_arr)
    np.save(out / "row_index.npy", row_index_arr)
    np.save(out / "split.npy", split_arr)
    np.save(out / "user_ids.npy", np.asarray(users, dtype=np.int64))

    stats = BuildStats(
        users=len(users),
        samples=len(labels_arr),
        train_samples=int((split_arr == "train").sum()),
        val_samples=int((split_arr == "val").sum()),
        test_samples=int((split_arr == "test").sum()),
        positives=int(labels_arr.sum()),
        item_vocab_size=SID_PAD + 1,
        max_hist_len=args.max_hist_len,
    )
    (out / "stats.json").write_text(json.dumps(asdict(stats), indent=2), encoding="utf-8")
    print(json.dumps(asdict(stats), indent=2))
    if skipped:
        print(f"skipped users: {skipped}")
    return stats


class RecIFDataset(Dataset):
    def __init__(self, cache_dir: Path, split: str):
        self.hist_sid = np.load(cache_dir / "hist_sid.npy", mmap_mode="r")
        self.hist_feedback = np.load(cache_dir / "hist_feedback.npy", mmap_mode="r")
        self.target_sid = np.load(cache_dir / "target_sid.npy", mmap_mode="r")
        self.labels = np.load(cache_dir / "labels.npy", mmap_mode="r")
        self.row_index = np.load(cache_dir / "row_index.npy", mmap_mode="r")
        split_arr = np.load(cache_dir / "split.npy", allow_pickle=True)
        self.indices = np.where(split_arr == split)[0].astype(np.int64)

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx: int):
        sample_id = int(self.indices[idx])
        row_id = int(self.row_index[sample_id])
        return {
            "hist_sid": torch.from_numpy(np.array(self.hist_sid[row_id], copy=True)).long(),
            "hist_feedback": torch.from_numpy(np.array(self.hist_feedback[row_id], copy=True)).float(),
            "target_sid": torch.from_numpy(np.array(self.target_sid[sample_id], copy=True)).long(),
            "label": torch.tensor(float(self.labels[sample_id])),
        }


def parse_answer(metadata) -> int:
    meta = json.loads(metadata) if isinstance(metadata, str) else metadata
    answer = meta.get("answer")
    if answer == "是":
        return 1
    if answer == "否":
        return 0
    raise ValueError(f"unsupported answer: {answer!r}")


def message_text(messages) -> str:
    msg = json.loads(messages) if isinstance(messages, str) else messages
    texts = []
    for item in msg:
        for part in item.get("content", []):
            if isinstance(part, dict):
                texts.append(part.get("text", ""))
    return "\n".join(texts)


def parse_candidate_sid(messages) -> tuple[int, int, int] | None:
    matches = SID_RE.findall(message_text(messages))
    if not matches:
        return None
    return tuple(int(x) for x in matches[-1])


class OfficialLabelPredDataset(Dataset):
    def __init__(self, parquet_path: Path, pid2sid_path: Path, max_hist_len: int):
        self.max_hist_len = max_hist_len
        cols = [f"hist_{name}" for name in INTERACTIONS] + ["candidate_pid", "metadata", "messages"]
        df = pd.read_parquet(parquet_path, columns=cols)
        needed: set[int] = set()
        for name in INTERACTIONS:
            for vals in tqdm(df[f"hist_{name}"], desc=f"collect official hist_{name} pids"):
                needed.update(int(x) for x in as_list(vals) if not pd.isna(x))
        sid_map = load_sid_map(pid2sid_path, needed)

        hist_sid, hist_fb, target_sid, labels = [], [], [], []
        skipped = 0
        for row in tqdm(df.itertuples(index=False), total=len(df), desc="build official label_pred"):
            cand_sid = parse_candidate_sid(row.messages)
            if cand_sid is None:
                skipped += 1
                continue
            ordered: dict[tuple[int, int, int], np.ndarray] = {}
            for k, name in enumerate(INTERACTIONS):
                for pid in as_list(getattr(row, f"hist_{name}")):
                    sid = sid_map.get(int(pid))
                    if sid is None:
                        continue
                    if sid not in ordered:
                        ordered[sid] = np.zeros((len(INTERACTIONS),), dtype=np.float32)
                    ordered[sid][k] = 1.0
            items = list(ordered.items())[-max_hist_len:]
            h_sid = np.full((max_hist_len, 3), SID_PAD, dtype=np.int32)
            h_fb = np.zeros((max_hist_len, len(INTERACTIONS)), dtype=np.float32)
            offset = max_hist_len - len(items)
            for j, (sid, fb) in enumerate(items):
                h_sid[offset + j] = sid
                h_fb[offset + j] = fb
            hist_sid.append(h_sid)
            hist_fb.append(h_fb)
            target_sid.append(cand_sid)
            labels.append(parse_answer(row.metadata))

        self.hist_sid = np.asarray(hist_sid, dtype=np.int32)
        self.hist_feedback = np.asarray(hist_fb, dtype=np.float32)
        self.target_sid = np.asarray(target_sid, dtype=np.int32)
        self.labels = np.asarray(labels, dtype=np.float32)
        self.raw_rows = int(len(df))
        self.skipped = int(skipped)

    def __len__(self) -> int:
        return len(self.labels)

    def __getitem__(self, idx: int):
        return {
            "hist_sid": torch.from_numpy(np.array(self.hist_sid[idx], copy=True)).long(),
            "hist_feedback": torch.from_numpy(np.array(self.hist_feedback[idx], copy=True)).float(),
            "target_sid": torch.from_numpy(np.array(self.target_sid[idx], copy=True)).long(),
            "label": torch.tensor(float(self.labels[idx])),
        }


class RecIFLongviewSimulator(nn.Module):
    def __init__(self, sid_vocab: int = SID_PAD + 1, sid_dim: int = 64, hidden_dim: int = 128, n_layers: int = 2):
        super().__init__()
        self.sid_vocab = sid_vocab
        self.sid_dim = sid_dim
        self.hidden_dim = hidden_dim
        self.sid_emb = nn.ModuleList([nn.Embedding(sid_vocab, sid_dim, padding_idx=SID_PAD) for _ in range(3)])
        self.feedback_proj = nn.Linear(len(INTERACTIONS), sid_dim)
        enc_layer = nn.TransformerEncoderLayer(
            d_model=sid_dim, nhead=4, dim_feedforward=hidden_dim, dropout=0.1, batch_first=True
        )
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.scorer = nn.Sequential(
            nn.LayerNorm(sid_dim * 4),
            nn.Linear(sid_dim * 4, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, 1),
        )

    def encode_item(self, sid: torch.Tensor) -> torch.Tensor:
        return sum(emb(sid[..., i]) for i, emb in enumerate(self.sid_emb))

    def encode_state(self, hist_sid: torch.Tensor, hist_feedback: torch.Tensor) -> torch.Tensor:
        hist_item = self.encode_item(hist_sid)
        hist_x = hist_item + self.feedback_proj(hist_feedback)
        pad_mask = (hist_sid[..., 0] == SID_PAD)
        enc = self.encoder(hist_x, src_key_padding_mask=pad_mask)
        valid = (~pad_mask).float().unsqueeze(-1)
        return (enc * valid).sum(dim=1) / valid.sum(dim=1).clamp_min(1.0)

    def forward(self, hist_sid: torch.Tensor, hist_feedback: torch.Tensor, target_sid: torch.Tensor) -> torch.Tensor:
        state = self.encode_state(hist_sid, hist_feedback)
        item = self.encode_item(target_sid)
        feat = torch.cat([state, item, state * item, torch.abs(state - item)], dim=-1)
        return self.scorer(feat).squeeze(-1)


def evaluate(model, loader, device) -> dict:
    model.eval()
    losses, ys, ps = [], [], []
    loss_fn = nn.BCEWithLogitsLoss()
    with torch.no_grad():
        for batch in tqdm(loader, desc="eval", leave=False):
            hist_sid = batch["hist_sid"].to(device)
            hist_feedback = batch["hist_feedback"].to(device)
            target_sid = batch["target_sid"].to(device)
            y = batch["label"].to(device)
            logits = model(hist_sid, hist_feedback, target_sid)
            losses.append(loss_fn(logits, y).item())
            ys.append(y.cpu().numpy())
            ps.append(torch.sigmoid(logits).cpu().numpy())
    y_true = np.concatenate(ys)
    y_score = np.concatenate(ps)
    auc = roc_auc_score(y_true, y_score) if len(np.unique(y_true)) == 2 else 0.5
    return {"loss": float(np.mean(losses)), "auc": float(auc), "samples": int(len(y_true))}


def train(args: argparse.Namespace) -> None:
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(args.cuda)

    train_ds = RecIFDataset(args.cache_dir, "train")
    val_ds = RecIFDataset(args.cache_dir, "val")
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers, pin_memory=True)
    val_loader = None
    if len(val_ds):
        val_loader = DataLoader(val_ds, batch_size=args.eval_batch_size, shuffle=False, num_workers=args.num_workers, pin_memory=True)

    model = RecIFLongviewSimulator(sid_dim=args.sid_dim, hidden_dim=args.hidden_dim, n_layers=args.n_layers).to(device)
    pos = float(np.load(args.cache_dir / "labels.npy", mmap_mode="r")[train_ds.indices].sum())
    neg = max(1.0, len(train_ds) - pos)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([neg / max(pos, 1.0)], device=device))
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    best_auc = None
    best_loss = float("inf")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, args.epochs + 1):
        model.train()
        running = []
        for step, batch in enumerate(tqdm(train_loader, desc=f"epoch {epoch}")):
            hist_sid = batch["hist_sid"].to(device)
            hist_feedback = batch["hist_feedback"].to(device)
            target_sid = batch["target_sid"].to(device)
            y = batch["label"].to(device)
            logits = model(hist_sid, hist_feedback, target_sid)
            loss = loss_fn(logits, y)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            running.append(loss.item())
            if args.max_train_steps and step + 1 >= args.max_train_steps:
                break
        train_loss = float(np.mean(running))
        val = evaluate(model, val_loader, device) if val_loader is not None else None
        print(json.dumps({"epoch": epoch, "train_loss": train_loss, "val": val}, ensure_ascii=False))
        should_save = False
        if val is not None and (best_auc is None or val["auc"] > best_auc):
            best_auc = val["auc"]
            should_save = True
        if val is None and train_loss < best_loss:
            best_loss = train_loss
            should_save = True
        if should_save:
            torch.save({"model": model.state_dict(), "args": vars(args), "val": val}, args.output_dir / "best_simulator.pt")

    ckpt = torch.load(args.output_dir / "best_simulator.pt", map_location=device, weights_only=False)
    model.load_state_dict(ckpt["model"])
    official_ds = OfficialLabelPredDataset(args.official_test_parquet, args.video_pid2sid_parquet, args.max_hist_len)
    official_loader = DataLoader(
        official_ds,
        batch_size=args.eval_batch_size,
        shuffle=False,
        num_workers=args.official_num_workers,
        pin_memory=True,
    )
    official_test = evaluate(model, official_loader, device)
    official_test.update({"raw_rows": official_ds.raw_rows, "skipped_rows": official_ds.skipped})
    if official_test["samples"] != args.expected_official_test_rows:
        print(
            json.dumps(
                {
                    "warning": "official test parsed sample count differs from expected row count",
                    "expected": args.expected_official_test_rows,
                    "actual": official_test["samples"],
                    "skipped": official_ds.skipped,
                },
                ensure_ascii=False,
            )
        )
    result = {"best_val_auc": best_auc, "official_test": official_test}
    (args.output_dir / "simulator_metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--recif_parquet", type=Path, default=Path("/opt/gensim/datasets/OpenOneRec-RecIF/onerec_bench_release.parquet"))
    parser.add_argument("--official_test_parquet", type=Path, default=Path("/opt/gensim/datasets/OpenOneRec-RecIF/benchmark_data/label_pred/label_pred_test.parquet"))
    parser.add_argument("--video_pid2sid_parquet", type=Path, default=Path("/opt/gensim/datasets/OpenOneRec-RecIF/video_ad_pid2sid.parquet"))
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--output_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output/simulator"))
    parser.add_argument("--max_users", type=int, default=0)
    parser.add_argument("--max_hist_len", type=int, default=100)
    parser.add_argument("--max_targets_per_user", type=int, default=10)
    parser.add_argument("--val_user_percent", type=int, default=0)
    parser.add_argument("--expected_official_test_rows", type=int, default=346190)
    parser.add_argument("--build_cache", action="store_true")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--eval_batch_size", type=int, default=2048)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--official_num_workers", type=int, default=0)
    parser.add_argument("--sid_dim", type=int, default=64)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--n_layers", type=int, default=2)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seed", type=int, default=619607)
    parser.add_argument("--max_train_steps", type=int, default=0)
    args = parser.parse_args()

    if args.build_cache or not (args.cache_dir / "labels.npy").exists():
        build_cache(args)
    train(args)


if __name__ == "__main__":
    main()
