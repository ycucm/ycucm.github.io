#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/opt/gensim/recif_kuaisim_repro}"
PY_ENV="${PY_ENV:-/opt/pytorch/bin/activate}"

cd "$ROOT"
source "$PY_ENV"

python eval_real_ndcg.py \
  --cache_dir "$ROOT/cache" \
  --output "$ROOT/output_rebuttal/real_ndcg_metrics.json" \
  --onerec_model_dir /opt/gensim/models/OneRec-8B-pro \
  --qwen_model_dir /opt/gensim/models/Qwen3-0.6B \
  --kuaisim_ckpt "$ROOT/output_official/simulator/best_simulator.pt" \
  --rl4rs_ckpt "$ROOT/output_rl4rs_baseline/simulator/best_rl4rs_gru.pt" \
  --simulators gensim kuaisim rl4rs dgdpo \
  --eval_users 96 \
  --candidate_pool 256 \
  --catalog_items 5000 \
  --seeds 3 \
  --k 10
