#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/opt/gensim/recif_kuaisim_repro}"
PY_ENV="${PY_ENV:-/opt/pytorch/bin/activate}"

cd "$ROOT"
source "$PY_ENV"

python run_rl_benchmark.py \
  --cache_dir "$ROOT/cache" \
  --simulator_ckpt "$ROOT/output_official/simulator/best_simulator.pt" \
  --output "$ROOT/output_rebuttal/rl_metrics_kuaisim.json"

python run_rl4rs_baseline_benchmark.py \
  --cache_dir "$ROOT/cache" \
  --simulator_ckpt "$ROOT/output_rl4rs_baseline/simulator/best_rl4rs_gru.pt" \
  --output "$ROOT/output_rebuttal/rl_metrics_rl4rs_gru.json"

python run_qwen3_dgdpo_recif.py \
  --cache_dir "$ROOT/cache" \
  --model_dir /opt/gensim/models/Qwen3-0.6B \
  --output "$ROOT/output_rebuttal/rl_metrics_dgdpo_qwen3.json"

python run_rl_on_onerec_simulator.py \
  --cache_dir "$ROOT/cache" \
  --model_dir /opt/gensim/models/OneRec-8B-pro \
  --rerank_pool 50 \
  --output "$ROOT/output_rebuttal/rl_metrics_gensim_onerec8b.json"
