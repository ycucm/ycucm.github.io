#!/usr/bin/env python3
"""DGDPO-style RecIF user simulator backed by Qwen3-0.6B."""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer

from run_rl_on_onerec_simulator import evaluate_policy, load_catalog, train_a2c, train_td3_like
from train_simulator import INTERACTIONS, SID_PAD


SECTION_NAMES = {
    "longview": "long-view positives",
    "like": "likes",
    "follow": "follow-related positives",
    "forward": "shares",
    "not_interested": "negative feedback",
}


def sid_text(sid: tuple[int, int, int]) -> str:
    return f"A{sid[0]}-B{sid[1]}-C{sid[2]}"


def history_sections(h_sid: np.ndarray, h_fb: np.ndarray, limit: int = 8) -> str:
    sections: list[str] = []
    for k, name in enumerate(INTERACTIONS):
        vals = []
        for sid, fb in zip(h_sid, h_fb):
            if sid[0] == SID_PAD or fb[k] <= 0:
                continue
            vals.append(sid_text(tuple(int(x) for x in sid)))
        if vals:
            sections.append(f"{SECTION_NAMES[name]}: {', '.join(vals[-limit:])}")
    return "\n".join(sections) if sections else "No reliable interaction history."


def build_profile(h_sid: np.ndarray, h_fb: np.ndarray, limit: int = 6) -> str:
    pos, neg = [], []
    for sid, fb in zip(h_sid, h_fb):
        if sid[0] == SID_PAD:
            continue
        text = sid_text(tuple(int(x) for x in sid))
        if fb[0] > 0 or fb[1] > 0 or fb[2] > 0 or fb[3] > 0:
            pos.append(text)
        if fb[4] > 0:
            neg.append(text)
    return (
        "Optimized dynamic user profile:\n"
        f"- Stable positive interests: {', '.join(pos[-limit:]) if pos else 'unknown'}\n"
        f"- Avoided interests: {', '.join(neg[-limit:]) if neg else 'unknown'}\n"
        "- Diagnostic rule: prefer candidates matching recent positive SID patterns; penalize explicit negatives."
    )


class Qwen3DGDPOScorer:
    def __init__(self, model_dir: Path, device: torch.device, max_prompt_len: int, batch_size: int):
        self.device = device
        self.max_prompt_len = max_prompt_len
        self.batch_size = batch_size
        self.tokenizer = AutoTokenizer.from_pretrained(model_dir, trust_remote_code=True, local_files_only=True)
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.padding_side = "left"
        self.model = AutoModelForCausalLM.from_pretrained(
            model_dir,
            torch_dtype=torch.float16 if device.type == "cuda" else torch.float32,
            trust_remote_code=True,
            local_files_only=True,
        ).to(device)
        self.model.eval()
        self.yes_id = self.tokenizer.encode("是", add_special_tokens=False)[0]
        self.no_id = self.tokenizer.encode("否", add_special_tokens=False)[0]

    def build_prompt(
        self,
        profile: str,
        h_sid: np.ndarray,
        h_fb: np.ndarray,
        candidate_sid: tuple[int, int, int],
    ) -> str:
        user = (
            f"{profile}\n\n"
            "Observed RecIF interaction evidence:\n"
            f"{history_sections(h_sid, h_fb)}\n\n"
            f"Candidate video SID: {sid_text(candidate_sid)}\n"
            "Question: will this user long-view the candidate video? Answer with exactly one Chinese character: 是 or 否."
        )
        messages = [
            {
                "role": "system",
                "content": (
                    "You are the DGDPO diagnostic-and-treatment user simulator for sequential recommendation. "
                    "Use the optimized profile and interaction evidence to predict long-view feedback."
                ),
            },
            {"role": "user", "content": user},
        ]
        return self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )

    @torch.inference_mode()
    def qwen_scores(self, profile: str, h_sid: np.ndarray, h_fb: np.ndarray, candidate_sids: np.ndarray) -> np.ndarray:
        prompts = [self.build_prompt(profile, h_sid, h_fb, tuple(int(x) for x in sid)) for sid in candidate_sids]
        scores: list[float] = []
        for i in range(0, len(prompts), self.batch_size):
            toks = self.tokenizer(
                prompts[i : i + self.batch_size],
                padding=True,
                truncation=True,
                max_length=self.max_prompt_len,
                return_tensors="pt",
            ).to(self.device)
            out = self.model(**toks)
            last = torch.full((toks["input_ids"].shape[0],), toks["input_ids"].shape[1] - 1, device=self.device)
            logits = out.logits[torch.arange(toks["input_ids"].shape[0], device=self.device), last]
            yn = logits[:, [self.yes_id, self.no_id]].float().clamp(-50, 50)
            prob = torch.softmax(yn, dim=-1)[:, 0]
            scores.extend(torch.nan_to_num(prob, nan=0.5, posinf=1.0, neginf=0.0).cpu().numpy().tolist())
        return np.asarray(scores, dtype=np.float32)

    def recif_prior(self, h_sid: np.ndarray, h_fb: np.ndarray, candidate_sids: np.ndarray) -> np.ndarray:
        pos, neg = [], []
        for sid, fb in zip(h_sid, h_fb):
            if sid[0] == SID_PAD:
                continue
            if fb[0] > 0 or fb[1] > 0 or fb[2] > 0 or fb[3] > 0:
                pos.append(sid.astype(np.int64))
            if fb[4] > 0:
                neg.append(sid.astype(np.int64))

        priors = []
        for cand in candidate_sids.astype(np.int64):
            if pos:
                pos_sim = max(float(np.mean(cand == p)) for p in pos[-16:])
            else:
                pos_sim = 0.15
            if neg:
                neg_sim = max(float(np.mean(cand == n)) for n in neg[-16:])
            else:
                neg_sim = 0.0
            logit = -1.15 + 2.25 * pos_sim - 1.55 * neg_sim
            priors.append(1.0 / (1.0 + np.exp(-logit)))
        return np.asarray(priors, dtype=np.float32)

    def score_with_profile(self, profile: str, h_sid: np.ndarray, h_fb: np.ndarray, candidate_sids: np.ndarray) -> np.ndarray:
        qwen = self.qwen_scores(profile, h_sid, h_fb, candidate_sids)
        prior = self.recif_prior(h_sid, h_fb, candidate_sids)
        qwen_z = (qwen - float(qwen.mean())) / max(float(qwen.std()), 1e-6)
        prior_logit = np.log(np.clip(prior, 1e-4, 1.0 - 1e-4) / np.clip(1.0 - prior, 1e-4, 1.0))
        calibrated = 1.0 / (1.0 + np.exp(-(prior_logit + 0.35 * qwen_z)))
        return np.asarray(calibrated, dtype=np.float32).clip(0.02, 0.98)

    def score(self, h_sid: np.ndarray, h_fb: np.ndarray, candidate_sids: np.ndarray) -> np.ndarray:
        return self.score_with_profile(build_profile(h_sid, h_fb), h_sid, h_fb, candidate_sids)

    @torch.inference_mode()
    def item_embeddings(self, catalog_sid: np.ndarray, out_dim: int, seed: int) -> torch.Tensor:
        emb = self.model.get_input_embeddings().weight.detach()
        rows = []
        for sid in catalog_sid:
            ids = self.tokenizer.encode(sid_text(tuple(int(x) for x in sid)), add_special_tokens=False)
            ids_t = torch.tensor(ids, device=emb.device, dtype=torch.long)
            rows.append(emb.index_select(0, ids_t).mean(dim=0).float().cpu())
        item_emb = torch.stack(rows)
        if out_dim and out_dim < item_emb.shape[-1]:
            gen = torch.Generator().manual_seed(seed)
            proj = torch.randn(item_emb.shape[-1], out_dim, generator=gen) / (item_emb.shape[-1] ** 0.5)
            item_emb = item_emb @ proj
        return F.normalize(item_emb, dim=-1)


class DGDPORecIFEnv:
    def __init__(self, scorer, cache_dir: Path, catalog_sid, catalog_emb, max_depth: int, slate_size: int, seed: int, rerank_pool: int):
        self.scorer = scorer
        self.hist_sid = np.load(cache_dir / "hist_sid.npy", mmap_mode="r")
        self.hist_feedback = np.load(cache_dir / "hist_feedback.npy", mmap_mode="r")
        self.catalog_sid = catalog_sid
        self.catalog_emb = catalog_emb
        self.max_depth = max_depth
        self.slate_size = slate_size
        self.rerank_pool = max(slate_size, rerank_pool)
        self.rng = np.random.default_rng(seed)
        self.sid_to_idx = {tuple(map(int, sid)): i for i, sid in enumerate(catalog_sid.tolist())}
        self.reset()

    def reset(self):
        self.row = int(self.rng.integers(0, len(self.hist_sid)))
        self.h_sid = np.array(self.hist_sid[self.row], copy=True)
        self.h_fb = np.array(self.hist_feedback[self.row], copy=True)
        self.profile = build_profile(self.h_sid, self.h_fb)
        self.depth = 0
        return self.state()

    def state(self):
        vecs, weights = [], []
        for sid, fb in zip(self.h_sid, self.h_fb):
            if sid[0] == SID_PAD:
                continue
            idx = self.sid_to_idx.get(tuple(map(int, sid)))
            if idx is None:
                continue
            vecs.append(self.catalog_emb[idx])
            weights.append(1.0 + float(fb[0]) + 0.5 * float(fb[1]) - 0.5 * float(fb[4]))
        if not vecs:
            return torch.zeros(self.catalog_emb.shape[-1])
        w = torch.tensor(weights).clamp_min(0.1).unsqueeze(-1)
        return F.normalize((torch.stack(vecs) * w).sum(dim=0) / w.sum(), dim=-1)

    def topk_by_action(self, action, k=None):
        q = F.normalize(action.view(1, -1), dim=-1).cpu()
        scores = (self.catalog_emb @ q.T).squeeze(-1)
        return torch.topk(scores, k=min(k or self.slate_size, len(scores))).indices

    def update_profile(self, chosen_sid: np.ndarray, positive: bool) -> None:
        label = "recent accepted SID" if positive else "recent rejected SID"
        self.profile = (
            build_profile(self.h_sid, self.h_fb)
            + f"\n- DGDPO treatment update: {label} {sid_text(tuple(int(x) for x in chosen_sid))}."
        )

    def step(self, action):
        pool_idx = self.topk_by_action(action, self.rerank_pool)
        pool = self.catalog_sid[pool_idx.numpy()]
        probs = self.scorer.score_with_profile(self.profile, self.h_sid, self.h_fb, pool)
        keep = np.argsort(-probs)[: self.slate_size]
        item_idx = pool_idx[keep]
        cand = pool[keep]
        slate_probs = probs[keep]
        reward = float(np.mean(slate_probs))
        chosen_pos = int(np.argmax(slate_probs))
        chosen_sid = cand[chosen_pos].astype(np.int32)
        positive = self.rng.random() < float(slate_probs[chosen_pos])
        fb = np.zeros((len(INTERACTIONS),), dtype=np.float32)
        fb[0] = 1.0 if positive else 0.0
        fb[4] = 0.0 if positive else 1.0
        self.h_sid = np.concatenate([self.h_sid[1:], chosen_sid[None]], axis=0)
        self.h_fb = np.concatenate([self.h_fb[1:], fb[None]], axis=0)
        self.update_profile(chosen_sid, bool(positive))
        self.depth += 1
        done = self.depth >= self.max_depth or (self.depth > 3 and self.rng.random() > float(slate_probs[chosen_pos]))
        return self.state(), reward, done, {"items": item_idx.numpy().tolist(), "probs": slate_probs.tolist()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--model_dir", type=Path, default=Path("/opt/gensim/models/Qwen3-0.6B"))
    parser.add_argument("--output", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_qwen3_dgdpo/rl_metrics_qwen3_dgdpo.json"))
    parser.add_argument("--catalog_items", type=int, default=1000)
    parser.add_argument("--state_dim", type=int, default=128)
    parser.add_argument("--slate_size", type=int, default=5)
    parser.add_argument("--rerank_pool", type=int, default=30)
    parser.add_argument("--max_depth", type=int, default=10)
    parser.add_argument("--train_episodes", type=int, default=30)
    parser.add_argument("--eval_episodes", type=int, default=20)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--score_batch_size", type=int, default=16)
    parser.add_argument("--max_prompt_len", type=int, default=1024)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seed", type=int, default=619607)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(args.cuda)

    scorer = Qwen3DGDPOScorer(args.model_dir, device, args.max_prompt_len, args.score_batch_size)
    catalog_sid = load_catalog(args.cache_dir, args.catalog_items, args.seed)
    catalog_emb = scorer.item_embeddings(catalog_sid, args.state_dim, args.seed)
    env = DGDPORecIFEnv(scorer, args.cache_dir, catalog_sid, catalog_emb, args.max_depth, args.slate_size, args.seed, args.rerank_pool)
    dim = catalog_emb.shape[-1]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    results = []
    for name, trainer in [
        ("TD3", lambda: train_td3_like(env, dim, args, device, hac=False)),
        ("A2C", lambda: train_a2c(env, dim, args, device, supervised=False)),
        ("SA2C", lambda: train_a2c(env, dim, args, device, supervised=True)),
        ("HAC", lambda: train_td3_like(env, dim, args, device, hac=True)),
    ]:
        actor = trainer()
        result = evaluate_policy(env, actor, args.eval_episodes, name, device)
        result["simulator"] = "DGDPO-Qwen3-0.6B"
        results.append(result)
        print(json.dumps(result, ensure_ascii=False))
        args.output.write_text(json.dumps(results, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
