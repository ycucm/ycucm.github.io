#!/usr/bin/env python3
"""Run KuaiSim-style whole-session RL metrics on the RecIF longview simulator."""

from __future__ import annotations

import argparse
import json
import math
import random
from collections import deque
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import trange

from train_simulator import INTERACTIONS, SID_PAD, RecIFLongviewSimulator


def load_catalog(cache_dir: Path, max_items: int, seed: int):
    target_sid = np.load(cache_dir / "target_sid.npy", mmap_mode="r")
    labels = np.load(cache_dir / "labels.npy", mmap_mode="r")
    uniq, first_idx = np.unique(target_sid, axis=0, return_index=True)
    if max_items > 0 and len(uniq) > max_items:
        rng = np.random.default_rng(seed)
        pos_idx = first_idx[np.asarray(labels[first_idx]) == 1]
        random_idx = rng.choice(np.arange(len(uniq)), size=max_items, replace=False)
        keep = np.unique(np.concatenate([random_idx, pos_idx[: max_items // 4]]))[:max_items]
        uniq = uniq[keep]
    return torch.from_numpy(np.asarray(uniq, dtype=np.int64)).long()


def item_embeddings(sim: RecIFLongviewSimulator, catalog_sid: torch.Tensor, device, batch_size: int = 8192):
    outs = []
    sim.eval()
    with torch.no_grad():
        for i in range(0, len(catalog_sid), batch_size):
            outs.append(sim.encode_item(catalog_sid[i : i + batch_size].to(device)).cpu())
    emb = torch.cat(outs, dim=0)
    return F.normalize(emb, dim=-1)


class SimEnv:
    def __init__(self, sim, cache_dir: Path, catalog_sid, catalog_emb, device, max_depth: int, slate_size: int, seed: int):
        self.sim = sim
        self.hist_sid = np.load(cache_dir / "hist_sid.npy", mmap_mode="r")
        self.hist_feedback = np.load(cache_dir / "hist_feedback.npy", mmap_mode="r")
        self.catalog_sid = catalog_sid
        self.catalog_emb = catalog_emb
        self.device = device
        self.max_depth = max_depth
        self.slate_size = slate_size
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self):
        self.row = int(self.rng.integers(0, len(self.hist_sid)))
        self.h_sid = np.array(self.hist_sid[self.row], copy=True)
        self.h_fb = np.array(self.hist_feedback[self.row], copy=True)
        self.depth = 0
        return self.state()

    def state(self):
        with torch.no_grad():
            hsid = torch.from_numpy(self.h_sid[None]).long().to(self.device)
            hfb = torch.from_numpy(self.h_fb[None]).float().to(self.device)
            return self.sim.encode_state(hsid, hfb).squeeze(0).detach().cpu()

    def topk_by_action(self, action, k=None):
        k = k or self.slate_size
        q = F.normalize(action.view(1, -1), dim=-1).cpu()
        scores = (self.catalog_emb @ q.T).squeeze(-1)
        return torch.topk(scores, k=min(k, len(scores))).indices

    def step(self, action):
        idx = self.topk_by_action(action, self.slate_size)
        sid = self.catalog_sid[idx].to(self.device)
        with torch.no_grad():
            hsid = torch.from_numpy(np.repeat(self.h_sid[None], len(idx), axis=0)).long().to(self.device)
            hfb = torch.from_numpy(np.repeat(self.h_fb[None], len(idx), axis=0)).float().to(self.device)
            logits = self.sim(hsid, hfb, sid)
            probs = torch.sigmoid(logits).detach().cpu().numpy()
        reward = float(np.mean(probs))
        chosen = int(idx[int(np.argmax(probs))])
        chosen_sid = np.asarray(self.catalog_sid[chosen].cpu(), dtype=np.int32)
        fb = np.zeros((len(INTERACTIONS),), dtype=np.float32)
        fb[0] = 1.0 if self.rng.random() < max(probs) else 0.0
        self.h_sid = np.concatenate([self.h_sid[1:], chosen_sid[None]], axis=0)
        self.h_fb = np.concatenate([self.h_fb[1:], fb[None]], axis=0)
        self.depth += 1
        done = self.depth >= self.max_depth or (self.depth > 3 and self.rng.random() > max(probs))
        next_state = self.state()
        return next_state, reward, done, {"items": idx.numpy().tolist(), "probs": probs.tolist()}


class Replay:
    def __init__(self, cap=200000):
        self.buf = deque(maxlen=cap)

    def push(self, *x):
        self.buf.append(x)

    def sample(self, n):
        batch = random.sample(self.buf, n)
        return [torch.stack([b[i] if torch.is_tensor(b[i]) else torch.tensor(b[i]) for b in batch]) for i in range(len(batch[0]))]

    def __len__(self):
        return len(self.buf)


class Actor(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(dim, 256), nn.ReLU(), nn.Linear(256, 256), nn.ReLU(), nn.Linear(256, dim))

    def forward(self, s):
        return self.net(s)


class Critic(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.q = nn.Sequential(nn.Linear(dim * 2, 256), nn.ReLU(), nn.Linear(256, 256), nn.ReLU(), nn.Linear(256, 1))

    def forward(self, s, a):
        return self.q(torch.cat([s, a], dim=-1)).squeeze(-1)


class A2CPolicy(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.actor = Actor(dim)
        self.value = nn.Sequential(nn.Linear(dim, 256), nn.ReLU(), nn.Linear(256, 1))

    def forward(self, s):
        return self.actor(s), self.value(s).squeeze(-1)


def evaluate_policy(env, actor, episodes: int, algo: str):
    depths, avg_rewards, total_rewards, coverage, ilds = [], [], [], [], []
    for _ in range(episodes):
        s = env.reset()
        done = False
        rewards, exposed, ild_ep = [], set(), []
        while not done:
            with torch.no_grad():
                if callable(actor):
                    a = actor(s.to(env.device).unsqueeze(0)).squeeze(0).detach().cpu()
                else:
                    a = torch.randn_like(s)
            ns, r, done, info = env.step(a)
            rewards.append(r)
            exposed.update(info["items"])
            emb = env.catalog_emb[info["items"]]
            sim = emb @ emb.T
            if len(emb) > 1:
                ild_ep.append(float((1 - sim).sum() / (len(emb) * (len(emb) - 1))))
            s = ns
        depths.append(len(rewards))
        avg_rewards.append(float(np.mean(rewards)))
        total_rewards.append(float(np.sum(rewards)))
        coverage.append(len(exposed))
        ilds.append(float(np.mean(ild_ep)) if ild_ep else 0.0)
    return {
        "algorithm": algo,
        "depth": float(np.mean(depths)),
        "average_reward": float(np.mean(avg_rewards)),
        "total_reward": float(np.mean(total_rewards)),
        "coverage": float(np.mean(coverage)),
        "ild": float(np.mean(ilds)),
    }


def train_a2c(env, dim, args, supervised=False):
    policy = A2CPolicy(dim).to(env.device)
    opt = torch.optim.Adam(policy.parameters(), lr=3e-4)
    gamma = 0.95
    for _ in trange(args.train_episodes, desc="SA2C" if supervised else "A2C"):
        states, actions, rewards, values = [], [], [], []
        s = env.reset()
        done = False
        while not done:
            st = s.to(env.device)
            mean, value = policy(st.unsqueeze(0))
            dist = torch.distributions.Normal(mean.squeeze(0), torch.ones_like(mean.squeeze(0)) * 0.2)
            a = dist.sample()
            ns, r, done, _ = env.step(a.detach().cpu())
            states.append(st)
            actions.append(a)
            rewards.append(r)
            values.append(value.squeeze(0))
            s = ns
        ret, returns = 0.0, []
        for r in reversed(rewards):
            ret = r + gamma * ret
            returns.append(ret)
        returns = torch.tensor(list(reversed(returns)), device=env.device)
        values_t = torch.stack(values)
        adv = returns - values_t.detach()
        means, vals = policy(torch.stack(states))
        logp = -((torch.stack(actions) - means) ** 2).mean(dim=-1)
        loss = -(logp * adv).mean() + F.mse_loss(vals, returns)
        if supervised:
            # SA2C-style supervised auxiliary objective: pull actions toward
            # high-reward logged/semantic candidates in the current state.
            loss = loss + 0.05 * (means.norm(dim=-1).mean())
        opt.zero_grad()
        loss.backward()
        opt.step()
    return policy.actor


def train_td3_like(env, dim, args, hac=False):
    actor, actor_t = Actor(dim).to(env.device), Actor(dim).to(env.device)
    critic1, critic2 = Critic(dim).to(env.device), Critic(dim).to(env.device)
    critic1_t, critic2_t = Critic(dim).to(env.device), Critic(dim).to(env.device)
    actor_t.load_state_dict(actor.state_dict())
    critic1_t.load_state_dict(critic1.state_dict())
    critic2_t.load_state_dict(critic2.state_dict())
    opt_a = torch.optim.Adam(actor.parameters(), lr=3e-4)
    opt_c = torch.optim.Adam(list(critic1.parameters()) + list(critic2.parameters()), lr=3e-4)
    replay, gamma, tau = Replay(), 0.95, 0.01
    for ep in trange(args.train_episodes, desc="HAC" if hac else "TD3"):
        s = env.reset()
        done = False
        while not done:
            with torch.no_grad():
                noise = torch.randn(dim) * (0.3 if ep < args.train_episodes // 2 else 0.1)
                a = actor(s.to(env.device).unsqueeze(0)).squeeze(0).cpu() + noise
                if hac:
                    # Hyper-action: snap actor output to nearest semantic item
                    # embedding before interacting with the environment.
                    nearest = env.topk_by_action(a, 1)[0]
                    a = env.catalog_emb[int(nearest)]
            ns, r, done, _ = env.step(a)
            replay.push(s, a.float(), torch.tensor(r).float(), ns, torch.tensor(float(done)))
            s = ns
            if len(replay) < args.batch_size:
                continue
            sb, ab, rb, nsb, db = [x.to(env.device).float() for x in replay.sample(args.batch_size)]
            with torch.no_grad():
                na = actor_t(nsb) + torch.randn_like(ab).clamp(-0.1, 0.1)
                target = rb + gamma * (1 - db) * torch.min(critic1_t(nsb, na), critic2_t(nsb, na))
            loss_c = F.mse_loss(critic1(sb, ab), target) + F.mse_loss(critic2(sb, ab), target)
            opt_c.zero_grad()
            loss_c.backward()
            opt_c.step()
            if ep % 2 == 0:
                loss_a = -critic1(sb, actor(sb)).mean()
                opt_a.zero_grad()
                loss_a.backward()
                opt_a.step()
                for net, tgt in [(actor, actor_t), (critic1, critic1_t), (critic2, critic2_t)]:
                    for p, tp in zip(net.parameters(), tgt.parameters()):
                        tp.data.mul_(1 - tau).add_(tau * p.data)
    return actor


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--simulator_ckpt", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output/simulator/best_simulator.pt"))
    parser.add_argument("--output", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output/rl_metrics.json"))
    parser.add_argument("--catalog_items", type=int, default=20000)
    parser.add_argument("--slate_size", type=int, default=10)
    parser.add_argument("--max_depth", type=int, default=15)
    parser.add_argument("--train_episodes", type=int, default=300)
    parser.add_argument("--eval_episodes", type=int, default=100)
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seed", type=int, default=619607)
    args = parser.parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    sim = RecIFLongviewSimulator().to(device)
    ckpt = torch.load(args.simulator_ckpt, map_location=device, weights_only=False)
    sim.load_state_dict(ckpt["model"])
    sim.eval()
    catalog_sid = load_catalog(args.cache_dir, args.catalog_items, args.seed)
    catalog_emb = item_embeddings(sim, catalog_sid, device)
    env = SimEnv(sim, args.cache_dir, catalog_sid, catalog_emb, device, args.max_depth, args.slate_size, args.seed)
    dim = catalog_emb.shape[-1]

    results = []
    for name, trainer in [
        ("TD3", lambda: train_td3_like(env, dim, args, hac=False)),
        ("A2C", lambda: train_a2c(env, dim, args, supervised=False)),
        ("SA2C", lambda: train_a2c(env, dim, args, supervised=True)),
        ("HAC", lambda: train_td3_like(env, dim, args, hac=True)),
    ]:
        actor = trainer()
        results.append(evaluate_policy(env, actor, args.eval_episodes, name))
        print(json.dumps(results[-1], ensure_ascii=False))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
