# RecIF-Bench Offline RL Rebuttal Experiments

This package contains the cleaned code for the RecIF-Bench offline RL simulator
experiments used in the rebuttal.

## What Was Fixed

The previous OPE scripts reported very large `nDCG@10` values because they used
the simulator-predicted reward scores as the relevance labels:

```python
ndcg = ndcg_at_k(simulator_scores, policy_order, k)
```

That measures policy alignment with the simulator itself. It is not comparable
to the paper's held-out real-interaction nDCG.

The fixed evaluator is:

```bash
python eval_real_ndcg.py
```

It computes nDCG with true RecIF longview labels:

- sample a real positive target item from `labels.npy == 1`;
- sample negative target items from the same RecIF candidate catalog;
- let each simulator score the candidate pool to induce policy logits;
- rank candidates by the policy;
- compute nDCG using the real binary labels only.

Simulator scores are used only to model the learned policy preference. They are
not used as nDCG relevance labels.

## Files

- `train_simulator.py`  
  RecIF longview simulator training and official label-pred AUC evaluation.

- `run_rl_benchmark.py`  
  KuaiSim-style simulator RL benchmark for `TD3`, `A2C`, `SA2C`, and `HAC`.

- `run_rl_on_onerec_simulator.py`  
  GenSim / OpenOneRec simulator RL benchmark.

- `train_rl4rs_baseline.py`  
  RL4RS-style GRU response model training.

- `run_rl4rs_baseline_benchmark.py`  
  RL benchmark using the RL4RS-GRU simulator.

- `run_qwen3_dgdpo_recif.py`  
  DGDPO-style Qwen3-0.6B RecIF simulator benchmark.

- `eval_real_ndcg.py`  
  Fixed real-label nDCG/action-KL/ESS evaluator.

- `eval_ope_metrics_onerec8b_legacy_simscore.py` and `*_legacy_simscore.py`  
  Legacy simulator-score evaluators kept only for auditability. Do not use them
  for rebuttal nDCG.

## Expected Server Layout

Default paths assume:

```text
/opt/gensim/recif_kuaisim_repro
/opt/gensim/models/OneRec-8B-pro
/opt/gensim/models/Qwen3-0.6B
/opt/pytorch/bin/activate
```

Required cache files under:

```text
/opt/gensim/recif_kuaisim_repro/cache/
  hist_sid.npy
  hist_feedback.npy
  target_sid.npy
  labels.npy
  row_index.npy
```

Required checkpoints:

```text
/opt/gensim/recif_kuaisim_repro/output_official/simulator/best_simulator.pt
/opt/gensim/recif_kuaisim_repro/output_rl4rs_baseline/simulator/best_rl4rs_gru.pt
```

## Running

Copy this package into the experiment root:

```bash
rsync -av rl_rebuttal_package/ /opt/gensim/recif_kuaisim_repro/
```

Run the interaction-level RL metrics:

```bash
bash scripts/run_rl_metrics.sh
```

Run fixed real-label nDCG:

```bash
bash scripts/run_real_ndcg.sh
```

Outputs:

```text
/opt/gensim/recif_kuaisim_repro/output_rebuttal/
  rl_metrics_kuaisim.json
  rl_metrics_rl4rs_gru.json
  rl_metrics_dgdpo_qwen3.json
  rl_metrics_gensim_onerec8b.json
  real_ndcg_metrics.json
```

## Rebuttal Table

For the compact rebuttal table, use:

- `Depth`
- `Avg. Reward`
- `Total Reward`
- `real_nDCG@10`

The first three columns come from the corresponding `rl_metrics_*.json` file.
The final column comes from `real_ndcg_metrics.json`.

Recommended compact setting: report `SA2C` as the representative agent and
state that the same trend was checked for `TD3`, `A2C`, and `HAC`.

## Important Note

Do not mix `real_nDCG@10` with legacy simulator-score `nDCG@10`.

Legacy simulator-score nDCG can be close to 1.0 because the policy is evaluated
against the simulator's own reward model. The paper-style real-label nDCG is
much smaller because positives are sparse in the candidate pool.
