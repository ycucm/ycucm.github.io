#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from run_rl_benchmark import SimEnv, evaluate_policy, load_catalog, train_a2c, train_td3_like
from train_rl4rs_baseline import RL4RSGRUSimulator


@torch.no_grad()
def item_embeddings(sim: RL4RSGRUSimulator, catalog_sid: torch.Tensor, device, batch_size: int = 8192):
    outs = []
    sim.eval()
    for i in range(0, len(catalog_sid), batch_size):
        item = sim.item_proj(sim.encode_item(catalog_sid[i : i + batch_size].to(device))).cpu()
        outs.append(item)
    return F.normalize(torch.cat(outs, dim=0), dim=-1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--simulator_ckpt", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_rl4rs_baseline/simulator/best_rl4rs_gru.pt"))
    parser.add_argument("--output", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_rl4rs_baseline/rl_metrics_rl4rs_gru.json"))
    parser.add_argument("--catalog_items", type=int, default=1000)
    parser.add_argument("--slate_size", type=int, default=5)
    parser.add_argument("--max_depth", type=int, default=10)
    parser.add_argument("--train_episodes", type=int, default=30)
    parser.add_argument("--eval_episodes", type=int, default=20)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--sid_dim", type=int, default=64)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seed", type=int, default=619607)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(args.cuda)

    sim = RL4RSGRUSimulator(args.sid_dim, args.hidden_dim).to(device)
    ckpt = torch.load(args.simulator_ckpt, map_location=device, weights_only=False)
    sim.load_state_dict(ckpt["model"])
    sim.eval()
    catalog_sid = load_catalog(args.cache_dir, args.catalog_items, args.seed)
    catalog_emb = item_embeddings(sim, catalog_sid, device)
    env = SimEnv(sim, args.cache_dir, catalog_sid, catalog_emb, device, args.max_depth, args.slate_size, args.seed)
    dim = catalog_emb.shape[-1]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    results = []
    for name, trainer in [
        ("TD3", lambda: train_td3_like(env, dim, args, hac=False)),
        ("A2C", lambda: train_a2c(env, dim, args, supervised=False)),
        ("SA2C", lambda: train_a2c(env, dim, args, supervised=True)),
        ("HAC", lambda: train_td3_like(env, dim, args, hac=True)),
    ]:
        actor = trainer()
        result = evaluate_policy(env, actor, args.eval_episodes, name)
        results.append(result)
        print(json.dumps(result, ensure_ascii=False))
        args.output.write_text(json.dumps(results, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
