#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

from train_simulator import INTERACTIONS, SID_PAD


class RecIFSampleDataset(Dataset):
    def __init__(self, cache_dir: Path, split: str = "train", max_samples: int = 0, seed: int = 619607):
        self.hist_sid = np.load(cache_dir / "hist_sid.npy", mmap_mode="r")
        self.hist_feedback = np.load(cache_dir / "hist_feedback.npy", mmap_mode="r")
        self.target_sid = np.load(cache_dir / "target_sid.npy", mmap_mode="r")
        self.labels = np.load(cache_dir / "labels.npy", mmap_mode="r")
        self.row_index = np.load(cache_dir / "row_index.npy", mmap_mode="r")
        split_arr = np.load(cache_dir / "split.npy", allow_pickle=True)
        indices = np.where(split_arr == split)[0].astype(np.int64)
        if max_samples > 0 and len(indices) > max_samples:
            rng = np.random.default_rng(seed)
            pos = indices[np.asarray(self.labels[indices]) > 0.5]
            neg = indices[np.asarray(self.labels[indices]) <= 0.5]
            n_pos = min(len(pos), max_samples // 2)
            n_neg = max_samples - n_pos
            indices = np.concatenate(
                [
                    rng.choice(pos, size=n_pos, replace=False),
                    rng.choice(neg, size=min(len(neg), n_neg), replace=False),
                ]
            )
            rng.shuffle(indices)
        self.indices = indices

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        sample_id = int(self.indices[idx])
        row_id = int(self.row_index[sample_id])
        return {
            "hist_sid": torch.from_numpy(np.array(self.hist_sid[row_id], copy=True)).long(),
            "hist_feedback": torch.from_numpy(np.array(self.hist_feedback[row_id], copy=True)).float(),
            "target_sid": torch.from_numpy(np.array(self.target_sid[sample_id], copy=True)).long(),
            "label": torch.tensor(float(self.labels[sample_id])),
        }


class RL4RSGRUSimulator(nn.Module):
    """RL4RS-style supervised user response model with a recurrent interest encoder."""

    def __init__(self, sid_dim: int = 64, hidden_dim: int = 128):
        super().__init__()
        self.sid_emb = nn.ModuleList([nn.Embedding(SID_PAD + 1, sid_dim, padding_idx=SID_PAD) for _ in range(3)])
        self.feedback_proj = nn.Linear(len(INTERACTIONS), sid_dim)
        self.gru = nn.GRU(sid_dim, hidden_dim, batch_first=True)
        self.item_proj = nn.Linear(sid_dim, hidden_dim)
        self.attn = nn.Sequential(nn.Linear(hidden_dim * 4, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, 1))
        self.scorer = nn.Sequential(
            nn.Linear(hidden_dim * 4, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1),
        )

    def encode_item(self, sid: torch.Tensor) -> torch.Tensor:
        return sum(emb(sid[..., i].clamp(0, SID_PAD)) for i, emb in enumerate(self.sid_emb))

    def encode_state(self, hist_sid: torch.Tensor, hist_feedback: torch.Tensor, target_sid: torch.Tensor | None = None) -> torch.Tensor:
        hist_item = self.encode_item(hist_sid)
        hist_x = hist_item + self.feedback_proj(hist_feedback)
        pad_mask = hist_sid[..., 0] == SID_PAD
        valid = (~pad_mask).float()
        lengths = valid.sum(dim=1).long().clamp_min(1).cpu()
        packed = nn.utils.rnn.pack_padded_sequence(hist_x, lengths, batch_first=True, enforce_sorted=False)
        packed_out, h = self.gru(packed)
        out, _ = nn.utils.rnn.pad_packed_sequence(packed_out, batch_first=True, total_length=hist_x.shape[1])
        state = h[-1]
        if target_sid is None:
            return state
        item = self.item_proj(self.encode_item(target_sid))
        item_exp = item[:, None, :].expand_as(out)
        attn_feat = torch.cat([out, item_exp, out * item_exp, torch.abs(out - item_exp)], dim=-1)
        weights = self.attn(attn_feat).squeeze(-1).masked_fill(pad_mask, -1e9)
        weights = torch.softmax(weights, dim=-1)
        return torch.sum(out * weights.unsqueeze(-1), dim=1)

    def forward(self, hist_sid: torch.Tensor, hist_feedback: torch.Tensor, target_sid: torch.Tensor) -> torch.Tensor:
        state = self.encode_state(hist_sid, hist_feedback, target_sid)
        item = self.item_proj(self.encode_item(target_sid))
        feat = torch.cat([state, item, state * item, torch.abs(state - item)], dim=-1)
        return self.scorer(feat).squeeze(-1)


@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    ys, ps, losses = [], [], []
    loss_fn = nn.BCEWithLogitsLoss()
    for batch in tqdm(loader, desc="eval", leave=False):
        hist_sid = batch["hist_sid"].to(device)
        hist_feedback = batch["hist_feedback"].to(device)
        target_sid = batch["target_sid"].to(device)
        y = batch["label"].to(device)
        logits = model(hist_sid, hist_feedback, target_sid)
        losses.append(loss_fn(logits, y).item())
        ys.append(y.cpu().numpy())
        ps.append(torch.sigmoid(logits).cpu().numpy())
    y_true = np.concatenate(ys)
    y_score = np.concatenate(ps)
    auc = roc_auc_score(y_true, y_score) if len(np.unique(y_true)) == 2 else 0.5
    return {"loss": float(np.mean(losses)), "auc": float(auc), "samples": int(len(y_true))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--output_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_rl4rs_baseline/simulator"))
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--max_train_samples", type=int, default=500000)
    parser.add_argument("--max_eval_samples", type=int, default=100000)
    parser.add_argument("--batch_size", type=int, default=512)
    parser.add_argument("--eval_batch_size", type=int, default=1024)
    parser.add_argument("--sid_dim", type=int, default=64)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--lr", type=float, default=2e-3)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seed", type=int, default=619607)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(args.cuda)

    train_ds = RecIFSampleDataset(args.cache_dir, "train", args.max_train_samples, args.seed)
    eval_ds = RecIFSampleDataset(args.cache_dir, "train", args.max_eval_samples, args.seed + 1)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=2, pin_memory=True)
    eval_loader = DataLoader(eval_ds, batch_size=args.eval_batch_size, shuffle=False, num_workers=2, pin_memory=True)

    model = RL4RSGRUSimulator(args.sid_dim, args.hidden_dim).to(device)
    labels = np.load(args.cache_dir / "labels.npy", mmap_mode="r")
    pos = float(np.asarray(labels[train_ds.indices]).sum())
    neg = max(1.0, len(train_ds) - pos)
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([neg / max(pos, 1.0)], device=device))
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    metrics = {"config": {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()}, "epochs": []}
    best_auc = -1.0
    for epoch in range(1, args.epochs + 1):
        model.train()
        running = []
        for batch in tqdm(train_loader, desc=f"epoch {epoch}"):
            hist_sid = batch["hist_sid"].to(device)
            hist_feedback = batch["hist_feedback"].to(device)
            target_sid = batch["target_sid"].to(device)
            y = batch["label"].to(device)
            logits = model(hist_sid, hist_feedback, target_sid)
            loss = loss_fn(logits, y)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            running.append(float(loss.item()))
        ev = evaluate(model, eval_loader, device)
        ev["train_loss"] = float(np.mean(running))
        ev["epoch"] = epoch
        metrics["epochs"].append(ev)
        print(json.dumps(ev))
        if ev["auc"] >= best_auc:
            best_auc = ev["auc"]
            torch.save({"model": model.state_dict(), "config": vars(args), "metrics": ev}, args.output_dir / "best_rl4rs_gru.pt")
        (args.output_dir / "metrics.json").write_text(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
