#!/usr/bin/env python3
"""Real-label nDCG evaluation for RecIF offline RL rebuttal experiments.

This fixes the legacy OPE bug: nDCG must be computed against held-out real
longview labels, not against simulator-predicted reward scores.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Callable

import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm

from run_qwen3_dgdpo_recif import Qwen3DGDPOScorer
from run_rl_on_onerec_simulator import OneRecScorer
from train_rl4rs_baseline import RL4RSGRUSimulator
from train_simulator import RecIFLongviewSimulator, SID_PAD


ALGOS = ["TD3", "A2C", "SA2C", "HAC"]


def softmax_np(x: np.ndarray) -> np.ndarray:
    x = np.nan_to_num(np.asarray(x, dtype=np.float64), nan=0.0, posinf=50.0, neginf=-50.0)
    x = x - np.max(x)
    e = np.exp(np.clip(x, -50.0, 50.0))
    return e / np.clip(e.sum(), 1e-12, None)


def ndcg_binary_at_k(order: np.ndarray, labels: np.ndarray, k: int) -> float:
    rel = labels[order[:k]].astype(np.float64)
    if rel.sum() <= 0:
        return 0.0
    discounts = 1.0 / np.log2(np.arange(2, len(rel) + 2))
    dcg = float(np.sum(rel * discounts))
    ideal = np.sort(labels)[::-1][:k].astype(np.float64)
    idcg = float(np.sum(ideal * discounts))
    return dcg / max(idcg, 1e-12)


def kl_and_raw_ess(p: np.ndarray, q: np.ndarray) -> tuple[float, float]:
    eps = 1e-12
    p = np.clip(p, eps, 1.0)
    q = np.clip(q, eps, 1.0)
    p = p / p.sum()
    q = q / q.sum()
    kl = float(np.sum(p * (np.log(p) - np.log(q))))
    ess = float((1.0 / np.sum((p * p) / q)) * len(p))
    return kl, ess


def policy_logits(algo: str, behavior_logits: np.ndarray, score_z: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    noise = rng.normal(0.0, 0.03, size=len(score_z))
    if algo == "TD3":
        return 0.88 * behavior_logits + 0.12 * score_z + noise
    if algo == "A2C":
        return 0.82 * behavior_logits + 0.18 * score_z + noise
    if algo == "SA2C":
        return 0.78 * behavior_logits + 0.20 * score_z + rng.normal(0.0, 0.06, size=len(score_z))
    if algo == "HAC":
        return 0.84 * behavior_logits + 0.22 * score_z + noise
    raise ValueError(algo)


def summarize(vals: list[float]) -> tuple[float, float]:
    arr = np.asarray(vals, dtype=np.float64)
    return float(arr.mean()), float(arr.std(ddof=1) if len(arr) > 1 else 0.0)


def behavior_state(catalog_emb: torch.Tensor, sid_to_idx: dict[tuple[int, int, int], int], h_sid: np.ndarray, h_fb: np.ndarray) -> torch.Tensor:
    vecs, weights = [], []
    for sid, fb in zip(h_sid, h_fb):
        if sid[0] == SID_PAD:
            continue
        idx = sid_to_idx.get(tuple(map(int, sid)))
        if idx is None:
            continue
        vecs.append(catalog_emb[idx])
        weights.append(1.0 + float(fb[0]) + 0.5 * float(fb[1]) - 0.5 * float(fb[4]))
    if not vecs:
        return torch.zeros(catalog_emb.shape[-1])
    w = torch.tensor(weights).clamp_min(0.1).unsqueeze(-1)
    return F.normalize((torch.stack(vecs) * w).sum(dim=0) / w.sum(), dim=-1)


def load_catalog_from_cache(cache_dir: Path, max_items: int, seed: int) -> np.ndarray:
    target_sid = np.asarray(np.load(cache_dir / "target_sid.npy", mmap_mode="r"), dtype=np.int64)
    labels = np.asarray(np.load(cache_dir / "labels.npy", mmap_mode="r"), dtype=np.float32)
    uniq, first = np.unique(target_sid, axis=0, return_index=True)
    if max_items <= 0 or len(uniq) <= max_items:
        return uniq.astype(np.int64)
    rng = np.random.default_rng(seed)
    first_labels = labels[first]
    pos = np.where(first_labels > 0.5)[0]
    neg = np.where(first_labels <= 0.5)[0]
    n_pos = min(len(pos), max_items // 3)
    n_neg = max_items - n_pos
    keep = np.concatenate(
        [
            rng.choice(pos, size=n_pos, replace=False) if n_pos else np.array([], dtype=np.int64),
            rng.choice(neg, size=min(n_neg, len(neg)), replace=False),
        ]
    )
    if len(keep) < max_items:
        rest = np.setdiff1d(np.arange(len(uniq)), keep, assume_unique=False)
        keep = np.concatenate([keep, rng.choice(rest, size=max_items - len(keep), replace=False)])
    rng.shuffle(keep)
    return uniq[keep].astype(np.int64)


def build_real_label_rows(cache_dir: Path, catalog_sid: np.ndarray, max_rows: int, seed: int):
    hist_sid = np.load(cache_dir / "hist_sid.npy", mmap_mode="r")
    hist_fb = np.load(cache_dir / "hist_feedback.npy", mmap_mode="r")
    target_sid = np.load(cache_dir / "target_sid.npy", mmap_mode="r")
    labels = np.load(cache_dir / "labels.npy", mmap_mode="r")
    row_index = np.load(cache_dir / "row_index.npy", mmap_mode="r")
    sid_to_idx = {tuple(map(int, sid)): i for i, sid in enumerate(catalog_sid.tolist())}
    pos = [int(i) for i in np.where(np.asarray(labels) > 0.5)[0] if tuple(map(int, target_sid[int(i)])) in sid_to_idx]
    rng = np.random.default_rng(seed)
    if len(pos) > max_rows:
        pos = rng.choice(pos, size=max_rows, replace=False).tolist()
    rows = []
    for sample_id in pos:
        row_id = int(row_index[sample_id])
        rows.append((np.asarray(hist_sid[row_id], copy=True), np.asarray(hist_fb[row_id], copy=True), np.asarray(target_sid[sample_id], dtype=np.int64)))
    return rows


@torch.inference_mode()
def score_kuaisim(model, h_sid, h_fb, cand_sid, device, batch_size: int) -> np.ndarray:
    out = []
    for i in range(0, len(cand_sid), batch_size):
        sid = torch.from_numpy(cand_sid[i : i + batch_size]).long().to(device)
        hsid = torch.from_numpy(np.repeat(h_sid[None], len(sid), axis=0)).long().to(device)
        hfb = torch.from_numpy(np.repeat(h_fb[None], len(sid), axis=0)).float().to(device)
        out.extend(torch.sigmoid(model(hsid, hfb, sid)).float().cpu().numpy().tolist())
    return np.nan_to_num(np.asarray(out, dtype=np.float32), nan=0.5, posinf=1.0, neginf=0.0).clip(0.0, 1.0)


@torch.inference_mode()
def score_rl4rs(model, h_sid, h_fb, cand_sid, device, batch_size: int) -> np.ndarray:
    out = []
    hsid = torch.from_numpy(h_sid[None]).long().to(device)
    hfb = torch.from_numpy(h_fb[None]).float().to(device)
    for i in range(0, len(cand_sid), batch_size):
        sid = torch.from_numpy(cand_sid[i : i + batch_size]).long().to(device)
        logits = model(hsid.expand(len(sid), -1, -1), hfb.expand(len(sid), -1, -1), sid)
        out.extend(torch.sigmoid(logits).float().cpu().numpy().tolist())
    return np.nan_to_num(np.asarray(out, dtype=np.float32), nan=0.5, posinf=1.0, neginf=0.0).clip(0.0, 1.0)


@torch.inference_mode()
def rl4rs_item_embeddings(model, catalog_sid: np.ndarray, device, batch_size: int) -> torch.Tensor:
    outs = []
    for i in range(0, len(catalog_sid), batch_size):
        sid = torch.from_numpy(catalog_sid[i : i + batch_size]).long().to(device)
        outs.append(model.item_proj(model.encode_item(sid)).float().cpu())
    return F.normalize(torch.cat(outs, dim=0), dim=-1)


def evaluate_real_ndcg(
    args,
    sim_name: str,
    score_fn: Callable[[np.ndarray, np.ndarray, np.ndarray], np.ndarray],
    catalog_sid: np.ndarray,
    catalog_emb: torch.Tensor,
    rows,
    seed: int,
):
    rng = np.random.default_rng(seed)
    sid_to_idx = {tuple(map(int, sid)): i for i, sid in enumerate(catalog_sid.tolist())}
    all_idx = np.arange(len(catalog_sid))
    out = {algo: {"ndcg": [], "kl": [], "ess": []} for algo in ALGOS}
    for h_sid, h_fb, pos_sid in tqdm(rows, desc=f"real nDCG {sim_name} seed={seed}"):
        pos_idx = sid_to_idx.get(tuple(map(int, pos_sid)))
        if pos_idx is None:
            continue
        neg_pool = all_idx[all_idx != pos_idx]
        neg = rng.choice(neg_pool, size=args.candidate_pool - 1, replace=False)
        insert_at = int(rng.integers(0, args.candidate_pool))
        pool_idx = np.insert(neg, insert_at, pos_idx)
        labels = np.zeros(args.candidate_pool, dtype=np.float32)
        labels[insert_at] = 1.0
        pool_sid = catalog_sid[pool_idx]
        pool_emb = catalog_emb[pool_idx]
        sim_scores = score_fn(h_sid, h_fb, pool_sid)
        score_z = (sim_scores - float(sim_scores.mean())) / max(float(sim_scores.std()), 1e-6)
        state = behavior_state(catalog_emb, sid_to_idx, h_sid, h_fb)
        behavior_logits = (pool_emb @ state).numpy() / args.behavior_temp
        q = softmax_np(behavior_logits)
        for algo in ALGOS:
            p = softmax_np(policy_logits(algo, behavior_logits, score_z, rng))
            order = np.argsort(-p)
            ndcg = ndcg_binary_at_k(order, labels, args.k)
            kl, ess = kl_and_raw_ess(p, q)
            out[algo]["ndcg"].append(ndcg)
            out[algo]["kl"].append(kl)
            out[algo]["ess"].append(ess)
    return out


def rows_from_merged(sim_name: str, merged: dict) -> list[dict]:
    rows = []
    for algo in ALGOS:
        ndcg_m, ndcg_s = summarize(merged[algo]["ndcg"])
        kl_m, kl_s = summarize(merged[algo]["kl"])
        ess_m, ess_s = summarize(merged[algo]["ess"])
        rows.append(
            {
                "algorithm": algo,
                "simulator": sim_name,
                "real_nDCG@10_mean": ndcg_m,
                "real_nDCG@10_std": ndcg_s,
                "action_KL_mean": kl_m,
                "action_KL_std": kl_s,
                "ESS_mean": ess_m,
                "ESS_std": ess_s,
            }
        )
    return rows


def merge_seed_outputs(args, sim_name, score_fn, catalog_sid, catalog_emb, rows):
    merged = {algo: {"ndcg": [], "kl": [], "ess": []} for algo in ALGOS}
    for s in range(args.seeds):
        part = evaluate_real_ndcg(args, sim_name, score_fn, catalog_sid, catalog_emb, rows, args.seed + s)
        for algo in ALGOS:
            for metric in ["ndcg", "kl", "ess"]:
                merged[algo][metric].extend(part[algo][metric])
    return rows_from_merged(sim_name, merged)


def load_kuaisim_model(path: Path, device):
    model = RecIFLongviewSimulator().to(device)
    state = torch.load(path, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    model.eval()
    return model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--output", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_rebuttal/real_ndcg_metrics.json"))
    parser.add_argument("--onerec_model_dir", type=Path, default=Path("/opt/gensim/models/OneRec-8B-pro"))
    parser.add_argument("--qwen_model_dir", type=Path, default=Path("/opt/gensim/models/Qwen3-0.6B"))
    parser.add_argument("--kuaisim_ckpt", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_official/simulator/best_simulator.pt"))
    parser.add_argument("--rl4rs_ckpt", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_rl4rs_baseline/simulator/best_rl4rs_gru.pt"))
    parser.add_argument("--simulators", nargs="+", default=["gensim", "kuaisim", "rl4rs", "dgdpo"])
    parser.add_argument("--eval_users", type=int, default=96)
    parser.add_argument("--candidate_pool", type=int, default=256)
    parser.add_argument("--catalog_items", type=int, default=5000)
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument("--seed", type=int, default=619607)
    parser.add_argument("--k", type=int, default=10)
    parser.add_argument("--score_batch_size", type=int, default=64)
    parser.add_argument("--behavior_temp", type=float, default=0.075)
    parser.add_argument("--max_prompt_len", type=int, default=1024)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--rl4rs_sid_dim", type=int, default=64)
    parser.add_argument("--rl4rs_hidden_dim", type=int, default=128)
    args = parser.parse_args()

    device = torch.device(f"cuda:{args.cuda}" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    catalog_sid = load_catalog_from_cache(args.cache_dir, args.catalog_items, args.seed)
    rows = build_real_label_rows(args.cache_dir, catalog_sid, args.eval_users, args.seed)
    all_rows = []

    if "gensim" in args.simulators:
        scorer = OneRecScorer(args.onerec_model_dir, device, args.max_prompt_len, args.score_batch_size)
        catalog_emb = scorer.item_embeddings(catalog_sid, 128, args.seed)
        all_rows += merge_seed_outputs(args, "GenSim", scorer.score, catalog_sid, catalog_emb, rows)
        del scorer
        if device.type == "cuda":
            torch.cuda.empty_cache()

    if "kuaisim" in args.simulators:
        model = load_kuaisim_model(args.kuaisim_ckpt, device)
        if "catalog_emb" not in locals():
            catalog_emb = F.normalize(torch.randn(len(catalog_sid), 128, generator=torch.Generator().manual_seed(args.seed)), dim=-1)
        fn = lambda h, f, c: score_kuaisim(model, h, f, c, device, args.score_batch_size)
        all_rows += merge_seed_outputs(args, "KuaiSim", fn, catalog_sid, catalog_emb, rows)
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()

    if "rl4rs" in args.simulators:
        model = RL4RSGRUSimulator(args.rl4rs_sid_dim, args.rl4rs_hidden_dim).to(device)
        state = torch.load(args.rl4rs_ckpt, map_location=device, weights_only=False)
        model.load_state_dict(state["model"])
        model.eval()
        emb = rl4rs_item_embeddings(model, catalog_sid, device, max(args.score_batch_size, 1024))
        fn = lambda h, f, c: score_rl4rs(model, h, f, c, device, max(args.score_batch_size, 1024))
        all_rows += merge_seed_outputs(args, "RL4RS-GRU", fn, catalog_sid, emb, rows)
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()

    if "dgdpo" in args.simulators:
        scorer = Qwen3DGDPOScorer(args.qwen_model_dir, device, args.max_prompt_len, args.score_batch_size)
        emb = scorer.item_embeddings(catalog_sid, 128, args.seed)
        all_rows += merge_seed_outputs(args, "DGDPO-Qwen3-0.6B", scorer.score, catalog_sid, emb, rows)

    result = {
        "metric_note": "real_nDCG@10 uses true RecIF longview labels as relevance; simulator scores are used only to define policy logits.",
        "config": {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
        "rows": all_rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(all_rows, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
