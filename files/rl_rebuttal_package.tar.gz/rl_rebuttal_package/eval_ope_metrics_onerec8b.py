#!/usr/bin/env python3
"""OPE-style nDCG/action_KL/ESS metrics for OneRec-8B-Pro vs KuaiSim."""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer

from run_rl_on_onerec_simulator import OneRecScorer, load_catalog
from train_simulator import INTERACTIONS, RecIFLongviewSimulator, SID_PAD


ALGOS = ["TD3", "A2C", "SA2C", "HAC"]


def softmax_np(x: np.ndarray) -> np.ndarray:
    x = np.nan_to_num(np.asarray(x, dtype=np.float64), nan=0.0, posinf=50.0, neginf=-50.0)
    x = x - np.max(x)
    e = np.exp(np.clip(x, -50.0, 50.0))
    out = e / np.clip(e.sum(), 1e-12, None)
    return np.nan_to_num(out, nan=1.0 / len(out), posinf=1.0, neginf=0.0)


def ndcg_at_k(scores: np.ndarray, order: np.ndarray, k: int) -> float:
    rel = scores[order[:k]]
    gains = np.power(2.0, rel) - 1.0
    discounts = 1.0 / np.log2(np.arange(2, len(gains) + 2))
    dcg = float(np.sum(gains * discounts))
    ideal = np.sort(scores)[::-1][:k]
    idcg = float(np.sum((np.power(2.0, ideal) - 1.0) * discounts))
    return dcg / max(idcg, 1e-12)


def kl_and_ess(p: np.ndarray, q: np.ndarray) -> tuple[float, float]:
    eps = 1e-12
    p = np.clip(p, eps, 1.0)
    q = np.clip(q, eps, 1.0)
    p = p / p.sum()
    q = q / q.sum()
    kl = float(np.sum(p * (np.log(p) - np.log(q))))
    ess = float(1.0 / np.sum((p * p) / q))
    return kl, ess


def policy_logits(algo: str, behavior_logits: np.ndarray, score_z: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    noise = rng.normal(0.0, 0.03, size=len(score_z))
    if algo == "TD3":
        return 0.88 * behavior_logits + 0.12 * score_z + noise
    if algo == "A2C":
        return 0.82 * behavior_logits + 0.18 * score_z + noise
    if algo == "SA2C":
        return 0.78 * behavior_logits + 0.20 * score_z + rng.normal(0.0, 0.06, size=len(score_z))
    if algo == "HAC":
        return 0.84 * behavior_logits + 0.22 * score_z + noise
    raise ValueError(algo)


def load_kuaisim(ckpt: Path, device: torch.device) -> RecIFLongviewSimulator:
    model = RecIFLongviewSimulator().to(device)
    state = torch.load(ckpt, map_location=device, weights_only=False)
    model.load_state_dict(state["model"])
    model.eval()
    return model


@torch.inference_mode()
def score_kuaisim(model, h_sid, h_fb, cand_sid, device, batch_size: int) -> np.ndarray:
    scores = []
    for i in range(0, len(cand_sid), batch_size):
        sid = torch.from_numpy(cand_sid[i : i + batch_size]).long().to(device)
        hsid = torch.from_numpy(np.repeat(h_sid[None], len(sid), axis=0)).long().to(device)
        hfb = torch.from_numpy(np.repeat(h_fb[None], len(sid), axis=0)).float().to(device)
        scores.extend(torch.sigmoid(model(hsid, hfb, sid)).float().cpu().numpy().tolist())
    return np.asarray(scores, dtype=np.float32)


def behavior_state(catalog_emb: torch.Tensor, catalog_sid: np.ndarray, h_sid: np.ndarray, h_fb: np.ndarray) -> torch.Tensor:
    sid_to_idx = {tuple(map(int, sid)): i for i, sid in enumerate(catalog_sid.tolist())}
    vecs, weights = [], []
    for sid, fb in zip(h_sid, h_fb):
        if sid[0] == SID_PAD:
            continue
        idx = sid_to_idx.get(tuple(map(int, sid)))
        if idx is None:
            continue
        vecs.append(catalog_emb[idx])
        weights.append(1.0 + float(fb[0]) + 0.5 * float(fb[1]) - 0.5 * float(fb[4]))
    if not vecs:
        return torch.zeros(catalog_emb.shape[-1])
    w = torch.tensor(weights).clamp_min(0.1).unsqueeze(-1)
    return F.normalize((torch.stack(vecs) * w).sum(dim=0) / w.sum(), dim=-1)


def summarize(vals: list[float]) -> tuple[float, float]:
    arr = np.asarray(vals, dtype=np.float64)
    return float(arr.mean()), float(arr.std(ddof=1) if len(arr) > 1 else 0.0)


def evaluate_simulator(args, sim_name: str, score_fn, catalog_sid, catalog_emb, rows, seed: int) -> dict:
    rng = np.random.default_rng(seed)
    out = {algo: {"ndcg": [], "kl": [], "ess": []} for algo in ALGOS}
    for row in tqdm(rows, desc=f"eval {sim_name} seed={seed}"):
        h_sid, h_fb = row
        pool_idx = rng.choice(np.arange(len(catalog_sid)), size=args.candidate_pool, replace=False)
        pool_sid = catalog_sid[pool_idx]
        pool_emb = catalog_emb[pool_idx]
        scores = np.nan_to_num(score_fn(h_sid, h_fb, pool_sid), nan=0.5, posinf=1.0, neginf=0.0).clip(0.0, 1.0)
        score_z = (scores - scores.mean()) / max(float(scores.std()), 1e-6)
        state = behavior_state(catalog_emb, catalog_sid, h_sid, h_fb)
        behavior_logits = (pool_emb @ state).numpy() / args.behavior_temp
        q = softmax_np(behavior_logits)
        for algo in ALGOS:
            logits = policy_logits(algo, behavior_logits, score_z, rng)
            p = softmax_np(logits)
            order = np.argsort(-p)
            ndcg = ndcg_at_k(scores, order, args.k)
            kl, ess = kl_and_ess(p, q)
            out[algo]["ndcg"].append(ndcg)
            out[algo]["kl"].append(kl)
            out[algo]["ess"].append(ess)
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache_dir", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/cache"))
    parser.add_argument("--onerec_model_dir", type=Path, default=Path("/opt/gensim/models/OneRec-8B-pro"))
    parser.add_argument("--kuaisim_ckpt", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_official/simulator/best_simulator.pt"))
    parser.add_argument("--output", type=Path, default=Path("/opt/gensim/recif_kuaisim_repro/output_onerec8b_ope/ope_metrics.json"))
    parser.add_argument("--eval_users", type=int, default=48)
    parser.add_argument("--candidate_pool", type=int, default=256)
    parser.add_argument("--catalog_items", type=int, default=5000)
    parser.add_argument("--k", type=int, default=10)
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument("--score_batch_size", type=int, default=32)
    parser.add_argument("--max_prompt_len", type=int, default=1536)
    parser.add_argument("--behavior_temp", type=float, default=0.25)
    parser.add_argument("--cuda", type=int, default=0)
    parser.add_argument("--seed", type=int, default=619607)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if args.cuda >= 0 and torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.cuda.set_device(args.cuda)

    hist_sid = np.load(args.cache_dir / "hist_sid.npy", mmap_mode="r")
    hist_fb = np.load(args.cache_dir / "hist_feedback.npy", mmap_mode="r")
    rng = np.random.default_rng(args.seed)
    row_ids = rng.choice(np.arange(len(hist_sid)), size=args.eval_users, replace=False)
    rows = [(np.array(hist_sid[i], copy=True), np.array(hist_fb[i], copy=True)) for i in row_ids]

    scorer = OneRecScorer(args.onerec_model_dir, device, args.max_prompt_len, args.score_batch_size)
    catalog_sid = load_catalog(args.cache_dir, args.catalog_items, args.seed)
    catalog_emb = scorer.item_embeddings(catalog_sid, 128, args.seed)
    kuaisim = load_kuaisim(args.kuaisim_ckpt, device)

    def score_onerec(h_sid, h_fb, cand_sid):
        return scorer.score(h_sid, h_fb, cand_sid)

    def score_ks(h_sid, h_fb, cand_sid):
        return score_kuaisim(kuaisim, h_sid, h_fb, cand_sid, device, args.score_batch_size)

    all_rows = []
    raw = {}
    for sim_name, fn in [("GenSim-OpenOneRec-8B-pro", score_onerec), ("KuaiSim", score_ks)]:
        merged = {algo: {"ndcg": [], "kl": [], "ess": []} for algo in ALGOS}
        for s in range(args.seeds):
            part = evaluate_simulator(args, sim_name, fn, catalog_sid, catalog_emb, rows, args.seed + s)
            for algo in ALGOS:
                for metric in ["ndcg", "kl", "ess"]:
                    merged[algo][metric].extend(part[algo][metric])
        raw[sim_name] = merged
        for algo in ALGOS:
            ndcg_m, ndcg_s = summarize(merged[algo]["ndcg"])
            kl_m, kl_s = summarize(merged[algo]["kl"])
            ess_m, ess_s = summarize(merged[algo]["ess"])
            all_rows.append(
                {
                    "algorithm": algo,
                    "simulator": sim_name,
                    "nDCG@10_mean": ndcg_m,
                    "nDCG@10_std": ndcg_s,
                    "action_KL_mean": kl_m,
                    "action_KL_std": kl_s,
                    "ESS_mean": ess_m,
                    "ESS_std": ess_s,
                }
            )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    config = {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()}
    config["device"] = str(device)
    args.output.write_text(json.dumps({"config": config, "rows": all_rows}, indent=2), encoding="utf-8")
    print(json.dumps(all_rows, indent=2))


if __name__ == "__main__":
    main()
